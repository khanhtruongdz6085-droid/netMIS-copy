# NetCafeMIS — mở trong IntelliJ IDEA

Yêu cầu: JDK 21 trở lên (JDK 25/27 hiện có của bạn cũng dùng được).

## Mở và chạy trong IntelliJ

1. Giải nén toàn bộ ZIP ra một thư mục mới, không chạy trực tiếp trong ZIP.
2. Chọn File > Open, chọn file pom.xml trong thư mục NetCafeMIS rồi chọn Open as Project / New Window nếu được hỏi.
3. Chờ Maven nạp dự án. Nếu IntelliJ hỏi SDK, chọn JDK đã cài trong File > Project Structure > Project > SDK (phiên bản 21 trở lên).
4. Mở src/main/java/netcafe/Main.java, bấm tam giác xanh cạnh hàm main rồi chọn Run 'Main.main()'. Tạo cấu hình chạy mới bằng nút này thay vì dùng cấu hình Main cũ.

Nếu chưa chạy được: Build > Rebuild Project; kiểm tra Project Structure > Modules > Dependencies có Module SDK hợp lệ. Nếu IntelliJ chưa nhận Maven, nhấp phải pom.xml > Add as Maven Project.

## Chạy ngay, không cần IntelliJ hoặc Maven

Có sẵn NetCafeMIS.jar đã biên dịch cho Java 21. Windows: nhấp đúp Chay-menu.bat (cần lệnh java trong PATH, phiên bản 21 trở lên).

Hoặc mở terminal tại thư mục này:

```text
java -jar NetCafeMIS.jar
java -jar NetCafeMIS.jar --all
java -jar NetCafeMIS.jar --query 5
java -jar NetCafeMIS.jar --group 2
```

## Biên dịch lại nếu đã chỉnh sửa nguồn

```text
mvn package
java -jar target/netcafe-intellij-1.0.0.jar
```

JAR ở thư mục gốc là bản đóng gói tại thời điểm gửi, không tự cập nhật khi sửa mã. Khi phát triển, hãy chạy Main trong IntelliJ hoặc biên dịch lại bằng Maven.

Nguồn Java được giữ nguyên từng byte so với java.zip. Chỉ chuyển main/java và test/java vào src/, thêm pom.xml, tài liệu và gói chạy. Không mang theo .idea và .iml cũ gắn với SDK ms-25. Chưa thay đổi DAO hoặc quy tắc nghiệp vụ.

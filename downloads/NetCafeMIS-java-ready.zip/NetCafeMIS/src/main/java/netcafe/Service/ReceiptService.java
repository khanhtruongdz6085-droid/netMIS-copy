package netcafe.Service;


import netcafe.enums.*;
import netcafe.exception.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.Employee;

import java.math.BigDecimal;

import static netcafe.Service.ServiceChecks.*;

/** Lập duy nhất một hóa đơn cho phiên đã kết thúc. */
public final class ReceiptService {
    private final NetCafeData data;

    ReceiptService(NetCafeData data) {
        this.data = data;
    }

    public Receipt issueReceipt(String id, Session session, Employee employee) {
        unique(data.receipts, id);
        registered(data.sessions, session);
        registered(data.employees, employee);
        if (session.getSessionStatus() != SessionStatus.COMPLETED) {
            throw new SessionStateException("Chỉ lập hóa đơn khi phiên đã kết thúc");
        }
        activeEmployee(employee);
        if (data.receipts.findBySession(session).isPresent())
            throw new ReceiptAlreadyExistsException("Phiên đã có hóa đơn");
        BigDecimal serviceAmount = BigDecimal.ZERO;
        for (FoodService service : data.services.findBySession(session))
            serviceAmount = serviceAmount.add(service.getTotal());
        Receipt receipt = new Receipt(id, session, employee, serviceAmount, session.calculateAmount());
        data.receipts.save(receipt, data);
        return receipt;
    }
}


package netcafe.Service;

import netcafe.enums.*;
import netcafe.exception.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.Employee;
import netcafe.model.NetSpecs.Food;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

import static netcafe.Service.ServiceChecks.*;

/** Gộp dòng món, kiểm tra kho rồi ghi đơn và trừ tồn. */
public final class FoodOrderService {
    private final NetCafeData data;

    FoodOrderService(NetCafeData data) {
        this.data = data;
    }

    public FoodService order(String id, Session session, Employee employee, LocalDateTime time,
                             Food[] items, int[] quantities) {
        synchronized (data) {
            return orderLocked(id, session, employee, time, items, quantities);
        }
    }

    private FoodService orderLocked(String id, Session session, Employee employee, LocalDateTime time,
                                    Food[] items, int[] quantities) {
        unique(data.services, id);
        registered(data.sessions, session);
        registered(data.employees, employee);
        if (session.getSessionStatus() != SessionStatus.ACTIVE) {
            throw new SessionStateException("Chỉ được gọi món khi phiên đang hoạt động");
        }
        activeEmployee(employee);
        if (time == null || time.isBefore(session.getTimeStart())) {
            throw new InvalidTimeException("Giờ gọi món thiếu hoặc trước giờ mở phiên");
        }
        if (items == null || quantities == null || items.length == 0
                || items.length != quantities.length) {
            throw new InvalidOrderException("Món và số lượng phải cùng số phần tử và không rỗng");
        }
        // Merge repeated foods before checking stock: 2 waters + 3 waters needs 5.
        Map<Food, Integer> ordered = new LinkedHashMap<>();
        for (int i = 0; i < items.length; i++) {
            registered(data.foods, items[i]);
            if (quantities[i] <= 0) throw new InvalidOrderException("Số lượng món phải lớn hơn 0");
            int previous = ordered.containsKey(items[i]) ? ordered.get(items[i]) : 0;
            if (quantities[i] > Integer.MAX_VALUE - previous)
                throw new InvalidOrderException("Tổng số lượng món vượt giới hạn số nguyên");
            ordered.put(items[i], previous + quantities[i]);
        }
        // Validate the whole order first. A rejected order does not reduce any stock.
        for (Map.Entry<Food, Integer> line : ordered.entrySet()) {
            if (line.getValue() > line.getKey().getStockQuantity())
                throw new InvalidOrderException("Món " + line.getKey().getId() + " không đủ hàng: cần "
                    + line.getValue() + ", còn " + line.getKey().getStockQuantity());
        }
        FoodService service = new FoodService(id, session, employee, time, ordered);
        data.services.save(service, data);
        session.recordFoodService(service, data);
        for (Map.Entry<Food, Integer> line : ordered.entrySet())
            line.getKey().reduceStock(line.getValue(), data);
        return service;
    }
}


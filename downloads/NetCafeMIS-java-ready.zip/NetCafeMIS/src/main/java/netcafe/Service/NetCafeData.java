package netcafe.Service;

import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;
import netcafe.dao.*;


/** Shared lists for the services of one cafe. */
final class NetCafeData implements DaoQueryContext {
    final ComputerSectionDao sections = new ComputerSectionDao(this);
    final ComputerDao computers = new ComputerDao(this);
    final CustomerDao customers = new CustomerDao(this);
    final EmployeeDao employees = new EmployeeDao(this);
    final FoodDao foods = new FoodDao(this);
    final SessionDao sessions = new SessionDao(this);
    final FoodServiceDao services = new FoodServiceDao(this);
    final ReceiptDao receipts = new ReceiptDao(this);
    final PaymentDao payments = new PaymentDao(this);

    public java.util.List<ComputerSection> getSections() { return sections.findAll(); }
    public java.util.List<Computer> getComputers() { return computers.findAll(); }
    public java.util.List<Customer> getCustomers() { return customers.findAll(); }
    public java.util.List<Employee> getEmployees() { return employees.findAll(); }
    public java.util.List<Food> getFoods() { return foods.findAll(); }
    public java.util.List<Session> getSessions() { return sessions.findAll(); }
    public java.util.List<FoodService> getServices() { return services.findAll(); }
    public java.util.List<Receipt> getReceipts() { return receipts.findAll(); }
    public java.util.List<Payment> getPayments() { return payments.findAll(); }
}

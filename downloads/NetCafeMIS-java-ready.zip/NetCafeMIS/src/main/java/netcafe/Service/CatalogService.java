package netcafe.Service;

import netcafe.enums.*;
import netcafe.exception.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import static netcafe.Service.ServiceChecks.*;

/** Thêm dữ liệu danh mục và nhập tồn kho theo quy tắc nghiệp vụ. */
public final class CatalogService {
    private final NetCafeData data;

    CatalogService(NetCafeData data) {
        this.data = data;
    }

    public void addSection(ComputerSection value) { add(data.sections, value, data); }
    public void addCustomer(Customer value) { add(data.customers, value, data); }
    public void addEmployee(Employee value) { add(data.employees, value, data); }
    public void addFood(Food value) {
        required(value, "food").ensureUnattached();
        add(data.foods, value, data);
        value.attach(data);
    }

    public void restockFood(Food food, int quantity) {
        synchronized (data) {
            registered(data.foods, food);
            food.restock(quantity, data);
        }
    }

    public void addComputer(Computer value) {
        required(value, "computer");
        value.ensureUnattached();
        registered(data.sections, value.getSection());
        if (value.getComputerStatus() == ComputerStatus.IN_USE) {
            throw new ComputerUnavailableException("Không thể thêm máy ở trạng thái IN_USE khi chưa có phiên");
        }
        add(data.computers, value, data);
        value.attach(data);
    }
}


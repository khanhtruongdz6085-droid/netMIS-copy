package netcafe;

import netcafe.exception.ValidationException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Scanner;

/** Reads and validates values typed at the console. */
final class ConsoleInput {
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter
        .ofPattern("uuuu-MM-dd").withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter
        .ofPattern("uuuu-MM-dd HH:mm").withResolverStyle(ResolverStyle.STRICT);
    private final Scanner scanner;

    ConsoleInput(Scanner scanner) { this.scanner = scanner; }

    String line(String prompt) {
        System.out.print(prompt);
        return scanner.hasNextLine() ? scanner.nextLine() : null;
    }

    String required(String prompt) {
        String value = line(prompt);
        if (value == null || value.trim().isEmpty())
            throw new ValidationException("Không được để trống: " + prompt.trim());
        return value.trim();
    }

    int number(String prompt, int min, int max) {
        String value = required(prompt);
        try {
            int result = Integer.parseInt(value);
            if (result >= min && result <= max) return result;
        } catch (NumberFormatException ignored) { }
        throw new ValidationException("Cần nhập số nguyên từ " + min + " đến " + max + ".");
    }

    BigDecimal money(String prompt) {
        String value = required(prompt);
        try {
            BigDecimal result = new BigDecimal(value);
            if (result.signum() >= 0) return result;
        } catch (NumberFormatException ignored) { }
        throw new ValidationException("Số tiền phải là số không âm, ví dụ 15000.");
    }

    LocalDate date(String prompt) {
        String value = required(prompt);
        try { return LocalDate.parse(value, DATE_FORMAT); }
        catch (DateTimeParseException error) {
            throw new ValidationException("Ngày sai định dạng hoặc không tồn tại. Ví dụ: 2026-10-06");
        }
    }

    LocalDateTime time(String prompt) {
        String value = required(prompt);
        try { return LocalDateTime.parse(value, TIME_FORMAT); }
        catch (DateTimeParseException error) {
            throw new ValidationException("Thời gian sai định dạng hoặc ngày không tồn tại. Ví dụ: 2026-10-07 08:30");
        }
    }
}

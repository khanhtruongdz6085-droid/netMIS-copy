package netcafe.dao;

import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;
import netcafe.exception.ValidationException;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static netcafe.dao.DaoQuerySupport.*;

/** Access to foods stored in memory. */
public final class FoodDao extends MemoryDao<Food> {
    private final DaoQueryContext context;

    public FoodDao(DaoQueryContext context) { super(context); this.context = context; }

    public Optional<Food> findByName(String name) {
        return stream().filter(food -> food.getFoodName().equalsIgnoreCase(name)).findFirst();
    }

    public List<String> timMonTheoGia(BigDecimal giaToiDa) {
        nonNegative(giaToiDa, "Giá tối đa");
        return stream().filter(f -> f.getPrice().compareTo(giaToiDa) <= 0)
            .sorted(Comparator.comparing(Food::getPrice).thenComparing(Food::getId))
            .map(f -> f.getId() + " | " + f.getFoodName() + " | " + money(f.getPrice())).collect(Collectors.toList());
    }

    public List<String> monDuocGoiNhieuNhat() {
        Map<Food, Integer> counts = details(context).stream().collect(Collectors.groupingBy(FoodOrderDetail::getFood,
            Collectors.summingInt(FoodOrderDetail::getOrderQuantity)));
        int max = counts.values().stream().mapToInt(Integer::intValue).max().orElse(0);
        return counts.entrySet().stream().filter(e -> e.getValue() == max)
            .sorted(Comparator.comparing(e -> e.getKey().getId()))
            .map(e -> e.getKey().getId() + " | " + e.getValue()).collect(Collectors.toList());
    }

    public List<String> monTonKhoThap(int nguongTon) {
        if (nguongTon < 0) throw new ValidationException("Ngưỡng tồn kho không được âm");
        return stream().filter(food -> food.getStockQuantity() <= nguongTon)
            .sorted(Comparator.comparingInt(Food::getStockQuantity).thenComparing(Food::getId))
            .map(food -> food.getId() + " | " + food.getFoodName() + " | còn "
                + food.getStockQuantity()).collect(Collectors.toList());
    }
}

package netcafe.dao;

import netcafe.Identifiable;
import netcafe.exception.DuplicateIdException;
import netcafe.exception.ValidationException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Iterator;
import java.util.Optional;
import java.util.stream.Stream;

/** Shared List-based storage for entity-specific DAOs; no database is used. */
public class MemoryDao<T extends Identifiable> implements Iterable<T> {
    private final List<T> values = new ArrayList<>();
    private final DaoQueryContext owner;

    protected MemoryDao(DaoQueryContext owner) { this.owner = owner; }

    public Optional<T> findById(String id) {
        return values.stream().filter(x -> x.getId().equals(id)).findFirst();
    }

    public List<T> findAll() {
        return Collections.unmodifiableList(values);
    }

    public Stream<T> stream() { return values.stream(); }
    public boolean contains(T value) { return values.contains(value); }
    public Iterator<T> iterator() { return findAll().iterator(); }

    /** Only the owning service context may change stored data; DAO getters remain for reports. */
    public void save(T value, DaoQueryContext caller) {
        if (caller == null || caller != owner)
            throw new ValidationException("Chỉ service của hệ thống được ghi dữ liệu DAO");
        if (value == null || value.getId() == null || value.getId().trim().isEmpty())
            throw new ValidationException("Đối tượng và mã ID không được để trống");
        if (findById(value.getId()).isPresent())
            throw new DuplicateIdException("Mã đã tồn tại: " + value.getId());
        values.add(value);
    }
}

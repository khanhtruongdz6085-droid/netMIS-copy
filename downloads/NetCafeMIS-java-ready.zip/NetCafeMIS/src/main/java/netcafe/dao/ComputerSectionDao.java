package netcafe.dao;

import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static netcafe.dao.DaoQuerySupport.*;

/** Access to computer sections stored in memory. */
public final class ComputerSectionDao extends MemoryDao<ComputerSection> {
    private final DaoQueryContext context;

    public ComputerSectionDao(DaoQueryContext context) { super(context); this.context = context; }

    public Optional<ComputerSection> findByName(String name) {
        return stream().filter(section -> section.getSectionName().equalsIgnoreCase(name)).findFirst();
    }

    public List<String> demMayTheoKhuVaTrangThai() {
        return stream().sorted(Comparator.comparing(ComputerSection::getId))
            .flatMap(s -> Arrays.stream(ComputerStatus.values()).map(status -> s.getId() + " | " + status + " | "
                + context.getComputers().stream().filter(x -> x.getSection() == s && x.getComputerStatus() == status).count()))
            .collect(Collectors.toList());
    }

    public List<String> timKhuGiaCao(BigDecimal nguongGia) {
        nonNegative(nguongGia, "Ngưỡng giá giờ");
        return stream().filter(s -> s.getSectionPrice().compareTo(nguongGia) > 0)
            .sorted(Comparator.comparing(ComputerSection::getSectionPrice).reversed())
            .map(s -> s.getId() + " | " + s.getSectionName() + " | " + money(s.getSectionPrice())).collect(Collectors.toList());
    }

    public List<String> doanhThuTheoKhuMay() {
        return stream().sorted(Comparator.comparing(ComputerSection::getId)).map(section -> {
            List<Receipt> paidReceipts = context.getReceipts().stream()
                .filter(r -> r.getSession().getComputer().getSection() == section && paid(r, context))
                .collect(Collectors.toList());
            BigDecimal computer = sum(paidReceipts.stream().map(Receipt::getComputerAmount).collect(Collectors.toList()));
            BigDecimal service = sum(paidReceipts.stream().map(Receipt::getServiceAmount).collect(Collectors.toList()));
            return section.getId() + " | " + money(computer) + " | " + money(service)
                + " | " + money(computer.add(service));
        }).collect(Collectors.toList());
    }
}

package netcafe.dao;

import netcafe.model.FoodService;
import netcafe.model.FoodOrderDetail;
import netcafe.model.Receipt;
import netcafe.model.Session;
import netcafe.model.customer.Customer;
import netcafe.Identifiable;
import netcafe.exception.EntityNotFoundException;
import netcafe.exception.ValidationException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/** Validation and formatting shared by DAO report methods. */
final class DaoQuerySupport {
    private DaoQuerySupport() {}

    static String existingId(String id, Collection<? extends Identifiable> items, String label) {
        if (id == null || id.trim().isEmpty())
            throw new ValidationException("Mã " + label + " không được để trống");
        String value = id.trim();
        if (items.stream().noneMatch(item -> item.getId().equals(value)))
            throw new EntityNotFoundException(label + " không tồn tại với mã " + value);
        return value;
    }

    static BigDecimal nonNegative(BigDecimal amount, String label) {
        if (amount == null || amount.signum() < 0)
            throw new ValidationException(label + " phải là số không âm");
        return amount;
    }

    static LocalDate requireDate(LocalDate day) {
        if (day == null) throw new ValidationException("Ngày không được để trống");
        return day;
    }

    static LocalDateTime requireMoment(LocalDateTime moment) {
        if (moment == null) throw new ValidationException("Thời điểm không được để trống");
        return moment;
    }

    static String money(BigDecimal amount) { return amount.stripTrailingZeros().toPlainString(); }

    static BigDecimal sum(Collection<BigDecimal> values) {
        return values.stream().reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    static Customer customer(Session session) { return session.getCustomer(); }

    static boolean paid(Receipt receipt, DaoQueryContext cafe) {
        return cafe.getPayments().stream().anyMatch(payment -> payment.getReceipt() == receipt);
    }

    static List<FoodOrderDetail> details(DaoQueryContext cafe) {
        return cafe.getServices().stream().flatMap(order -> order.getDetails().stream())
                .collect(Collectors.toList());
    }
}

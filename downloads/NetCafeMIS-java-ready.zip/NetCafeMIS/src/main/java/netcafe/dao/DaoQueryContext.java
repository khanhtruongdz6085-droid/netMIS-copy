package netcafe.dao;

import netcafe.model.FoodService;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;
import java.util.List;

/** Cấp các danh sách chỉ đọc để DAO truy vấn mối liên hệ giữa thực thể. */
public interface DaoQueryContext {
    List<ComputerSection> getSections();
    List<Computer> getComputers();
    List<Customer> getCustomers();
    List<Employee> getEmployees();
    List<Food> getFoods();
    List<Session> getSessions();
    List<FoodService> getServices();
    List<Receipt> getReceipts();
    List<Payment> getPayments();
}

package netcafe;
import java.math.BigDecimal;
/** Đối tượng có thể tự tính thành tiền. */
public interface Chargeable { BigDecimal calculateAmount(); }

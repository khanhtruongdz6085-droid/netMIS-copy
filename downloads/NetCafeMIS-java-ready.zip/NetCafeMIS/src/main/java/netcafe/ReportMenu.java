package netcafe;

import netcafe.Service.NetCafe;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/** Menu presentation of the DAO reports; DAOs never read from the keyboard. */
public final class ReportMenu {
    private static final BigDecimal SAMPLE_SECTION_PRICE = new BigDecimal("12000");
    private static final BigDecimal SAMPLE_PRICE_LIMIT = new BigDecimal("15000");
    private static final LocalDate SAMPLE_DAY = LocalDate.of(2026, 10, 6);
    private static final LocalDate SAMPLE_ORDER_DAY = LocalDate.of(2026, 10, 5);
    private static final LocalDateTime SAMPLE_AS_OF = LocalDateTime.of(2026, 10, 5, 12, 0);
    private static final int SAMPLE_STOCK_LIMIT = 5;

    private final NetCafe cafe;
    private final ConsoleInput input;

    ReportMenu(NetCafe cafe, ConsoleInput input) {
        this.cafe = cafe;
        this.input = input;
    }

    private static final String[] REPORT_TITLES = {
        "Máy trống, khu và giá giờ",
        "Máy bảo trì và khu",
        "Số máy theo khu và trạng thái",
        "Khu có giá > ngưỡng nhập",
        "Lịch sử phiên theo mã máy",
        "Phiên đang hoạt động",
        "Phiên hoàn tất >= 120 phút",
        "Phút chơi theo máy trong ngày nhập",
        "Máy chưa có phiên",
        "Tạm tính phiên đang chơi theo thời điểm nhập",
        "Lịch sử phiên theo mã khách",
        "Khách chưa có phiên",
        "Số phiên hoàn tất theo khách",
        "Món có giá <= ngưỡng nhập",
        "Chi tiết gọi món theo mã phiên",
        "Tiền món theo phiên",
        "Phiên hoàn tất không gọi món",
        "Món có số lượng gọi cao nhất",
        "Lần gọi món > ngưỡng nhập",
        "Nhân viên và đơn món theo ngày nhập",
        "Hóa đơn chưa thanh toán",
        "Doanh thu theo ngày thanh toán",
        "Giao dịch theo phương thức",
        "Hóa đơn lớn nhất",
        "Top 3 khách đã trả nhiều nhất",
        "Giá trị hóa đơn theo nhân viên lập",
        "Tiền còn thu theo khách",
        "Doanh thu theo khu máy",
        "Món có tồn kho <= ngưỡng nhập",
        "Phiên hoàn tất chưa có hóa đơn"
    };

    void runOne() {
        printChoices();
        int number = input.number("Chọn báo cáo (1-30): ", 1, 30);
        printRange(number, number, true);
    }

    void runGroup() {
        int group = input.number("Nhóm (1-3): ", 1, 3);
        printRange((group - 1) * 10 + 1, group * 10, true);
    }

    void runAll() { printRange(1, 30, true); }

    private void printChoices() {
        System.out.println("\n=== DANH SÁCH BÁO CÁO ===");
        for (int i = 0; i < REPORT_TITLES.length; i++)
            System.out.printf("%2d. %s%n", i + 1, REPORT_TITLES[i]);
    }

    /** Tham số mẫu giúp kết quả báo cáo dòng lệnh lặp lại được. */
    public static void printQueries(NetCafe cafe, int from, int to) {
        new ReportMenu(cafe, null).printRange(from, to, false);
    }

    private void printRange(int from, int to, boolean interactive) {
        System.out.println(interactive
            ? "NETCAFE MIS | BÁO CÁO JAVA LAMBDA | điều kiện nhập từ bàn phím"
            : "NETCAFE MIS | 30 JAVA LAMBDA QUERIES | sample 05-06/10/2026");
        for (int number = from; number <= to; number++) {
            List<String> rows = reportRows(number, interactive);
            System.out.printf("%nQ%02d | %s | %d row(s)%n", number, REPORT_TITLES[number - 1], rows.size());
            if (rows.isEmpty()) System.out.println("(Không có kết quả)");
            else rows.forEach(System.out::println);
        }
    }

    private List<String> reportRows(int number, boolean interactive) {
        switch (number) {
            case 1: return cafe.getComputerDao().lietKeMayTrong();
            case 2: return cafe.getComputerDao().lietKeMayBaoTri();
            case 3: return cafe.getComputerSectionDao().demMayTheoKhuVaTrangThai();
            case 4: return cafe.getComputerSectionDao().timKhuGiaCao(interactive ? input.money("Ngưỡng giá giờ (đồng): ") : SAMPLE_SECTION_PRICE);
            case 5: return cafe.getSessionDao().lichSuPhienTheoMay(interactive ? input.required("Mã máy: ") : "PC01");
            case 6: return cafe.getSessionDao().lietKePhienDangChoi();
            case 7: return cafe.getSessionDao().phienChoiTu120Phut();
            case 8: return cafe.getComputerDao().tongPhutChoiTheoMay(interactive ? input.date("Ngày (yyyy-MM-dd): ") : SAMPLE_DAY);
            case 9: return cafe.getComputerDao().mayChuaTungDuocSuDung();
            case 10: return cafe.getSessionDao().tamTinhTienPhienDangChoi(interactive ? input.time("Thời điểm (yyyy-MM-dd HH:mm): ") : SAMPLE_AS_OF);
            case 11: return cafe.getSessionDao().lichSuPhienTheoKhach(interactive ? input.required("Mã khách: ") : "C01");
            case 12: return cafe.getCustomerDao().xuatKhachChuaTungChoi();
            case 13: return cafe.getCustomerDao().demPhienHoanTatTheoKhach();
            case 14: return cafe.getFoodDao().timMonTheoGia(interactive ? input.money("Giá tối đa (đồng): ") : SAMPLE_PRICE_LIMIT);
            case 15: return cafe.getFoodServiceDao().chiTietGoiMonTheoPhien(interactive ? input.required("Mã phiên: ") : "S01");
            case 16: return cafe.getSessionDao().tongTienMonTheoPhien();
            case 17: return cafe.getSessionDao().phienHoanTatKhongGoiMon();
            case 18: return cafe.getFoodDao().monDuocGoiNhieuNhat();
            case 19: return cafe.getFoodServiceDao().lanGoiMonVuotNguong(interactive ? input.money("Ngưỡng tiền (đồng): ") : SAMPLE_PRICE_LIMIT);
            case 20: return cafe.getEmployeeDao().thongKeGoiMonTheoNhanVien(interactive ? input.date("Ngày gọi món (yyyy-MM-dd): ") : SAMPLE_ORDER_DAY);
            case 21: return cafe.getReceiptDao().hoaDonChuaThanhToan();
            case 22: return cafe.getPaymentDao().doanhThuTheoNgay();
            case 23: return cafe.getPaymentDao().thongKeThanhToanTheoPhuongThuc();
            case 24: return cafe.getReceiptDao().hoaDonGiaTriLonNhat();
            case 25: return cafe.getPaymentDao().topKhachThanhToanNhieuNhat();
            case 26: return cafe.getEmployeeDao().giaTriHoaDonTheoNhanVien();
            case 27: return cafe.getCustomerDao().tienConThuTheoKhach();
            case 28: return cafe.getComputerSectionDao().doanhThuTheoKhuMay();
            case 29: return cafe.getFoodDao().monTonKhoThap(
                interactive ? input.number("Ngưỡng tồn kho (0-1000000): ", 0, 1000000) : SAMPLE_STOCK_LIMIT);
            case 30: return cafe.getSessionDao().phienHoanTatChuaCoHoaDon();
            default: throw new IllegalArgumentException("Số truy vấn phải từ 1 đến 30");
        }
    }
}

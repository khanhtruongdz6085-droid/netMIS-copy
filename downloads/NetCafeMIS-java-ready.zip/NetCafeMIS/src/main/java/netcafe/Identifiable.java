package netcafe;
/** Thực thể có mã để DAO tìm kiếm và kiểm tra trùng. */
public interface Identifiable { String getId(); }

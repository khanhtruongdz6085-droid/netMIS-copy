package netcafe;
import netcafe.Service.NetCafe;
import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;
import java.math.BigDecimal;
import java.time.LocalDateTime;
/** Tạo bộ dữ liệu mẫu dùng chung cho menu và 30 truy vấn Java. */
public final class SampleData {
  private static BigDecimal v(long amount) { return BigDecimal.valueOf(amount); }
  private static LocalDateTime t(int hour, int minute) { return LocalDateTime.of(2026,10,5,hour,minute); }
  public static NetCafe create() {
    NetCafe cafe=new NetCafe();
    ComputerSection
            normal=new ComputerSection("CS01","Khu thường",v(12000)),
            vip=new ComputerSection("CS02","Khu VIP",v(20000));
    cafe.addSection(normal); cafe.addSection(vip);

    Computer
            pc1=new Computer("PC01",normal,ComputerStatus.AVAILABLE),
            pc2=new Computer("PC02",normal,ComputerStatus.AVAILABLE),
            pc3=new Computer("PC03",vip,ComputerStatus.AVAILABLE),
            pc4=new Computer("PC04",vip,ComputerStatus.AVAILABLE);
    cafe.addComputer(pc1);
    cafe.addComputer(pc2);
    cafe.addComputer(pc3);
    cafe.addComputer(pc4);
    cafe.addComputer(new Computer("PC05",normal,ComputerStatus.MAINTENANCE));
    cafe.addComputer(new Computer("PC06",vip,ComputerStatus.AVAILABLE));

    Customer
            c1=new Customer("C01","Lamine Yamal"),
            c2=new Customer("C02","Bruno Fernandes"),
            c3=new Customer("C03","Cristiano Ronaldo");
    Customer c4 = new Customer("C04","Lionel Messi");
    cafe.addCustomer(c1);
    cafe.addCustomer(c2);
    cafe.addCustomer(c3);
    cafe.addCustomer(c4);
    cafe.addCustomer(new Customer("C05","Khách chưa chơi"));

    Employee
            e1=new Employee("E01","Erik TenHag",EmployeeStatus.ACTIVE),
            e2=new Employee("E02","Anchelotti",EmployeeStatus.ACTIVE);
    cafe.addEmployee(e1);
    cafe.addEmployee(e2);
    cafe.addEmployee(new Employee("E03","Luis Enrique",EmployeeStatus.INACTIVE));

    Food
            f1=new Food("F01","Mì ly",v(13000),10),
            f2=new Food("F02","Nước ngọt",v(15000),12),
            f3=new Food("F03","Snack",v(7000),8);
    cafe.addFood(f1);
    cafe.addFood(f2);
    cafe.addFood(f3);

    Session s1=cafe.openSession("S01",c1,pc1,e1,t(8,0));
    cafe.order(
            "SV01",s1,e1,t(8,20),
            new Food[]{f1,f2},
            new int[]{1,1});

    Session s2=cafe.openSession("S02",c2,pc3,e2,t(9,0));
    cafe.order(
            "SV02",s2,e2,t(9,30),
            new Food[]{f1},
            new int[]{2});

    Session s3=cafe.openSession("S03",c3,pc4,e1,t(10,0));

    cafe.endSession(s1,t(10,0));
    cafe.endSession(s2,t(10,30));
    cafe.endSession(s3,t(11,0));

    Session s4=cafe.openSession("S04",c1,pc2,e2,t(11,0));
    cafe.order(
            "SV03",s4,e1,t(11,15),
            new Food[]{f2},
            new int[]{2});

    Receipt r1=cafe.issueReceipt("R01",s1,e2),
            r2=cafe.issueReceipt("R02",s2,e1);
    cafe.pay("P01",r1,t(10,5),PaymentMethod.CASH,r1.getTotalAmount());

    Session s5 = cafe.openSession("S05", c4, pc1, e1,
            LocalDateTime.of(2026, 10, 6, 9, 0));
    cafe.order("SV04", s5, e1, LocalDateTime.of(2026, 10, 6, 9, 30),
            new Food[]{f3}, new int[]{3});
    cafe.endSession(s5, LocalDateTime.of(2026, 10, 6, 12, 0));
    Receipt r3 = cafe.issueReceipt("R03", s5, e2);
    cafe.pay("P02", r3, LocalDateTime.of(2026, 10, 6, 12, 5),
            PaymentMethod.BANK_TRANSFER, r3.getTotalAmount());

    Session s6 = cafe.openSession("S06", c2, pc3, e2,
            LocalDateTime.of(2026, 10, 6, 12, 0));
    cafe.endSession(s6, LocalDateTime.of(2026, 10, 6, 13, 0));
    Receipt r4 = cafe.issueReceipt("R04", s6, e1);
    cafe.pay("P03", r4, LocalDateTime.of(2026, 10, 6, 13, 5),
            PaymentMethod.CARD, r4.getTotalAmount());
    return cafe;
  }
}

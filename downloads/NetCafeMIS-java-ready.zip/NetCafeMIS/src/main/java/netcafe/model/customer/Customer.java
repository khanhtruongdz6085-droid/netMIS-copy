package netcafe.model.customer;

import netcafe.Identifiable;
import netcafe.model.Checks;

/** Khách dùng máy; không có tài khoản hoặc hạng giảm giá. */
public final class Customer implements Identifiable {
    private final String id;
    private final String name;

    public Customer(String id, String name) {
        this.id = Checks.id(id);
        this.name = Checks.name(name);
    }

    public String getId() { return id; }
    public String getCustomerId() { return id; }
    public String getName() { return name; }
}

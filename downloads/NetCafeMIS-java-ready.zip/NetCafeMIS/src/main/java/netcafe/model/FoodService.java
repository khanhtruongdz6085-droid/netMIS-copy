package netcafe.model;
import netcafe.Chargeable;
import netcafe.Identifiable;
import netcafe.exception.InvalidOrderException;
import netcafe.model.NetSpecs.Employee;
import netcafe.model.NetSpecs.Food;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/** Một lần gọi món trong phiên, gồm nhiều dòng FoodOrderDetail. */
public final class FoodService implements Identifiable, Chargeable {
  // Attribute
  private final String serviceId;
  private final Session session;
  private final Employee employee;
  private final LocalDateTime timeStartService;
  private final List<FoodOrderDetail> details;


  // Constructor
  public FoodService(String id, Session session, Employee employee, LocalDateTime time,
                     Map<Food, Integer> quantities) {
    serviceId= Checks.id(id);
    this.session=Checks.required(session, "session");
    this.employee=Checks.required(employee, "employee");
    timeStartService=Checks.required(time, "time");
    if (quantities == null || quantities.isEmpty())
      throw new InvalidOrderException("Lần gọi món phải có ít nhất một món");
    List<FoodOrderDetail> lines = new ArrayList<>();
    for (Map.Entry<Food, Integer> entry : quantities.entrySet()) {
      if (entry.getValue() == null) throw new InvalidOrderException("Thiếu số lượng món");
      lines.add(new FoodOrderDetail(this, entry.getKey(), entry.getValue()));
    }
    details = Collections.unmodifiableList(lines);
  }
  // Getter
  public String getId() { return serviceId; }
  public String getServiceId() { return serviceId; }
  public Session getSession() { return session; }
  public Employee getEmployee() { return employee; }
  public LocalDateTime getTimeStartService() { return timeStartService; }
  public List<FoodOrderDetail> getDetails() { return details; }
  public BigDecimal getTotal() { return calculateAmount(); }
  public BigDecimal calculateAmount() { BigDecimal total=BigDecimal.ZERO; for (FoodOrderDetail d: details) total=total.add(d.calculateAmount()); return total; }
}

package netcafe.model;

import netcafe.Chargeable;
import netcafe.Identifiable;
import netcafe.model.NetSpecs.Employee;
import java.math.BigDecimal;

/** Hóa đơn chốt riêng tiền máy, tiền món và tổng tiền. */
public final class Receipt implements Identifiable, Chargeable {
    private final String id;
    private final Session session;
    private final Employee employee;
    private final BigDecimal serviceAmount;
    private final BigDecimal computerAmount;

    public Receipt(String id, Session session, Employee employee,
                   BigDecimal serviceAmount, BigDecimal computerAmount) {
        this.id = Checks.id(id);
        this.session = Checks.required(session, "session");
        this.employee = Checks.required(employee, "employee");
        this.serviceAmount = Checks.money(serviceAmount);
        this.computerAmount = Checks.money(computerAmount);
    }

    public String getId() { return id; }
    public String getReceiptId() { return id; }
    public Session getSession() { return session; }
    public Employee getEmployee() { return employee; }
    public BigDecimal getServiceAmount() { return serviceAmount; }
    public BigDecimal getComputerAmount() { return computerAmount; }
    public BigDecimal getTotalAmount() { return calculateAmount(); }
    public BigDecimal calculateAmount() { return computerAmount.add(serviceAmount); }
}

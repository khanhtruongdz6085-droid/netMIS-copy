package netcafe.model;
import java.math.BigDecimal;
import netcafe.exception.ValidationException;
public final class Checks {
  private Checks() {}

  public static String id(String value) {
    if (value == null || value.trim().isEmpty())
      throw new ValidationException("Mã hoặc tên không được để trống");
    return value.trim(); }

  public static String name(String value) { return id(value); }

  public static BigDecimal money(BigDecimal value) {
    if (value == null || value.signum() < 0)
      throw new ValidationException("Số tiền không được để trống hoặc âm");
    return value; }

  public static <T> T required(T value, String field) {
    if (value == null)
      throw new ValidationException("Thiếu dữ liệu: " + field);
    return value; }
}

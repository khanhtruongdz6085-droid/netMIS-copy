package netcafe.model;
import netcafe.Chargeable;
import netcafe.exception.InvalidOrderException;
import netcafe.model.NetSpecs.Food;

import java.math.BigDecimal;

/** Một món và số lượng trong lần gọi; thành tiền dùng giá món cố định. */
public final class FoodOrderDetail implements Chargeable {
  // Attribute
  private final FoodService service;
  private final Food food;
  private final int orderQuantity;

  // Constructor
  public FoodOrderDetail(FoodService service, Food food, int quantity) {
    this.service=Checks.required(service, "service");
    this.food=Checks.required(food, "food");
    if (quantity <= 0)
      throw new InvalidOrderException("Số lượng món phải lớn hơn 0");
    orderQuantity=quantity;
  }
  // Getter
  public FoodService getService() { return service; }
  public Food getFood() { return food; }
  public int getOrderQuantity() { return orderQuantity; }
  public BigDecimal calculateAmount() {
    return food.getPrice().multiply(BigDecimal.valueOf(orderQuantity)); }
}

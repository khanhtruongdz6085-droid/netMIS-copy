package netcafe.model.NetSpecs;
import netcafe.Identifiable;
import netcafe.model.Checks;
import netcafe.exception.InvalidOrderException;
import netcafe.exception.ValidationException;
import netcafe.dao.DaoQueryContext;

import java.math.BigDecimal;
/** Món có giá cố định và tồn kho giảm khi gọi, tăng khi nhập thêm. */
public final class Food implements Identifiable {
  // Attribute
  private final String foodId, foodName;
  private final BigDecimal price;
  private int stockQuantity;
  private DaoQueryContext owner;

  // Constructor
  public Food(String id, String name, BigDecimal price, int stockQuantity) {
    foodId= Checks.id(id);
    foodName=Checks.name(name);
    this.price=Checks.money(price);
    if (stockQuantity < 0) throw new ValidationException("Tồn kho ban đầu không được âm");
    this.stockQuantity=stockQuantity;
  }

  public String getId() { return foodId; }
  public String getFoodId() { return foodId; }
  public String getFoodName() { return foodName; }
  public BigDecimal getPrice() { return price; }
  public int getStockQuantity() { return stockQuantity; }

  /** A catalog service attaches the food when it enters the cafe's list. */
  public void ensureUnattached() {
    if (owner != null) throw new ValidationException("Món đã thuộc hệ thống khác");
  }

  public void attach(DaoQueryContext caller) {
    if (caller == null || !caller.getFoods().contains(this) || owner != null)
      throw new ValidationException("Món phải được thêm đúng một lần vào hệ thống");
    owner = caller;
  }

  public void restock(int quantity, DaoQueryContext caller) {
    if (caller == null || caller != owner)
      throw new ValidationException("Chỉ service được nhập hàng");
    if (quantity <= 0 || quantity > Integer.MAX_VALUE - stockQuantity)
      throw new ValidationException("Số lượng nhập kho phải dương và không vượt giới hạn số nguyên");
    stockQuantity += quantity;
  }

  public void reduceStock(int quantity, DaoQueryContext caller) {
    if (caller == null || caller != owner)
      throw new InvalidOrderException("Chỉ service được trừ tồn kho");
    if (quantity <= 0) throw new InvalidOrderException("Số lượng gọi món phải lớn hơn 0");
    if (quantity > stockQuantity)
      throw new InvalidOrderException("Món " + foodId + " không đủ hàng: cần " + quantity + ", còn " + stockQuantity);
    stockQuantity -= quantity;
  }
}

package netcafe.model;
import netcafe.Chargeable;
import netcafe.Identifiable;
import netcafe.dao.DaoQueryContext;
import netcafe.enums.ComputerStatus;
import netcafe.enums.SessionStatus;
import netcafe.exception.DuplicateIdException;
import netcafe.exception.InvalidOrderException;
import netcafe.exception.InvalidTimeException;
import netcafe.exception.SessionStateException;
import netcafe.model.NetSpecs.Computer;
import netcafe.model.NetSpecs.Employee;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Phiên sử dụng máy: giữ khách, máy, nhân viên mở, thời gian và đơn món. */
public final class Session implements Identifiable, Chargeable {
  // Attribute
  private final String sessionId;
  private final Customer customer;
  private final Computer computer;
  private final Employee openedBy;
  private final LocalDateTime timeStart;
  private final DaoQueryContext owner;
  private final List<FoodService> foodServices = new ArrayList<>();
  private LocalDateTime timeEnd;
  private SessionStatus sessionStatus;

  //Constructor
  public Session(String id, Customer customer, Computer computer, Employee openedBy, LocalDateTime start,
                 DaoQueryContext owner) {
    sessionId=Checks.id(id);
    this.customer=Checks.required(customer, "customer");
    this.computer=Checks.required(computer, "computer");
    this.openedBy=Checks.required(openedBy, "openedBy");
    timeStart=Checks.required(start, "start");
    this.owner=Checks.required(owner, "owner");
    sessionStatus=SessionStatus.ACTIVE;
  }

  public String getId() { return sessionId; }
  public String getSessionId() { return sessionId; }
  public Customer getCustomer() { return customer; }
  public Computer getComputer() { return computer; }
  public Employee getOpenedBy() { return openedBy; }
  public LocalDateTime getTimeStart() { return timeStart; }
  public LocalDateTime getTimeEnd() { return timeEnd; }
  public SessionStatus getSessionStatus() { return sessionStatus; }
  public List<FoodService> getFoodServices() { return Collections.unmodifiableList(foodServices); }

  /** Link a complete order to this active session. */
  public void recordFoodService(FoodService service, DaoQueryContext caller) {
    if (caller != owner) throw new InvalidOrderException("Chỉ hệ thống được ghi lần gọi món vào phiên");
    Checks.required(service, "foodService");
    if (!owner.getServices().contains(service))
      throw new InvalidOrderException("Lần gọi món chưa được lưu trong hệ thống");
    if (sessionStatus != SessionStatus.ACTIVE) throw new SessionStateException("Chỉ được gọi món khi phiên đang hoạt động: " + sessionId);
    if (service.getSession() != this) throw new InvalidOrderException("Lần gọi món thuộc phiên khác");
    if (service.getTimeStartService().isBefore(timeStart)) throw new InvalidTimeException("Giờ gọi món trước giờ mở phiên");
    for (FoodService old : foodServices) {
      if (old.getId().equals(service.getId())) throw new DuplicateIdException("Mã lần gọi món đã tồn tại: " + service.getId());
    }
    foodServices.add(service);
  }

  /** Kết thúc phiên sau khi service đã kiểm tra quyền ghi. */
  public void endSession(LocalDateTime end, DaoQueryContext caller) {
    if (caller != owner) throw new SessionStateException("Chỉ service được kết thúc phiên");
    if (sessionStatus != SessionStatus.ACTIVE) throw new SessionStateException("Phiên đã kết thúc: " + sessionId);
    if (end == null || !end.isAfter(timeStart)) throw new InvalidTimeException("Giờ kết thúc phải sau giờ mở phiên: " + sessionId);
    for (FoodService service : foodServices) {
      if (service.getTimeStartService().isAfter(end)) throw new InvalidTimeException("Có lần gọi món sau giờ kết thúc dự kiến");
    }
    timeEnd=end; sessionStatus=SessionStatus.COMPLETED;
    computer.setComputerStatus(ComputerStatus.AVAILABLE, owner);
  }
  public BigDecimal amountAt(LocalDateTime at) {
    if (at == null || at.isBefore(timeStart)) throw new InvalidTimeException("Thời điểm tính tiền thiếu hoặc trước giờ mở phiên: " + sessionId);
    long seconds=Duration.between(timeStart, at).getSeconds();
    return computer.getSection().getSectionPrice().multiply(BigDecimal.valueOf(seconds)).divide(BigDecimal.valueOf(3600), 0, RoundingMode.HALF_UP);
  }
  public BigDecimal calculateAmount() {
    if (timeEnd == null) throw new SessionStateException("Chưa thể chốt tiền khi phiên đang hoạt động: " + sessionId);
    return amountAt(timeEnd);
  }
}

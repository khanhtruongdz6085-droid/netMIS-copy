package netcafe.model.NetSpecs;
import netcafe.Identifiable;
import netcafe.enums.ComputerStatus;
import netcafe.model.Checks;
import netcafe.dao.DaoQueryContext;
import netcafe.exception.ValidationException;

/** Máy thuộc một khu; trạng thái được đổi qua nghiệp vụ phiên. */
public final class Computer implements Identifiable {
  // Attribute
  private final String computerId;
  private final ComputerSection section;
  private ComputerStatus computerStatus;
  private DaoQueryContext owner;
  // Constructor
  public Computer(String id, ComputerSection section, ComputerStatus status) {
    this.computerId = Checks.id(id);
    this.section = Checks.required(section, "section");
    this.computerStatus = Checks.required(status, "status");
  }
  // Getter implements Identifiable
  public String getId() { return computerId; }
  public String getComputerId() { return computerId; }
  public ComputerSection getSection() { return section; }
  public ComputerStatus getComputerStatus() { return computerStatus; }
  /** A catalog service attaches the computer when it enters the cafe's list. */
  public void ensureUnattached() {
    if (owner != null) throw new ValidationException("Máy đã thuộc hệ thống khác");
  }

  public void attach(DaoQueryContext caller) {
    if (caller == null || !caller.getComputers().contains(this) || owner != null)
      throw new ValidationException("Máy phải được thêm đúng một lần vào hệ thống");
    owner = caller;
  }
  public void setComputerStatus(ComputerStatus status, DaoQueryContext caller) {
    if (caller == null || caller != owner)
      throw new ValidationException("Chỉ service được đổi trạng thái máy");
    computerStatus = Checks.required(status, "status");
  }
}

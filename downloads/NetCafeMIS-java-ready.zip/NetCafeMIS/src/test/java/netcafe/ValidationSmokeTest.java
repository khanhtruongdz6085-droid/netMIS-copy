package netcafe;

import netcafe.Service.NetCafe;
import netcafe.enums.PaymentMethod;
import netcafe.enums.ComputerStatus;
import netcafe.enums.EmployeeStatus;
import netcafe.exception.*;
import netcafe.model.FoodService;
import netcafe.model.Payment;
import netcafe.model.Session;
import netcafe.model.NetSpecs.Computer;
import netcafe.model.NetSpecs.ComputerSection;
import netcafe.model.NetSpecs.Employee;
import netcafe.model.NetSpecs.Food;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/** Business-rule checks using the same sample shown in the menu. No test library needed. */
public final class ValidationSmokeTest {
    private static int passed;

    private static void expect(Class<? extends RuntimeException> type, Runnable action) {
        try {
            action.run();
        } catch (RuntimeException error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName()
                    + ", got " + error.getClass().getSimpleName(), error);
            passed++;
            return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }

    public static void main(String[] args) {
        try { System.setOut(new java.io.PrintStream(System.out, true, "UTF-8")); }
        catch (java.io.UnsupportedEncodingException error) { throw new IllegalStateException(error); }
        NetCafe cafe = SampleData.create();
        LocalDateTime nextDay = LocalDateTime.of(2026, 10, 7, 8, 0);

        expect(DuplicateIdException.class, () -> cafe.addCustomer(new Customer("C01", "Trùng mã")));
        expect(ValidationException.class, () -> cafe.addCustomer(new Customer("  ", "Tên")));
        expect(EntityNotFoundException.class, () -> cafe.openSession("S07", new Customer("C99", "Lạ"),
                cafe.getComputers().get(5), cafe.getEmployees().get(0), nextDay));
        expect(InactiveEmployeeException.class, () -> cafe.openSession("S07", cafe.getCustomers().get(4),
                cafe.getComputers().get(5), cafe.getEmployees().get(2), nextDay));
        expect(ComputerUnavailableException.class, () -> cafe.openSession("S07", cafe.getCustomers().get(4),
                cafe.getComputers().get(4), cafe.getEmployees().get(0), nextDay));
        expect(ActiveSessionExistsException.class, () -> cafe.openSession("S07", cafe.getCustomers().get(0),
                cafe.getComputers().get(5), cafe.getEmployees().get(0), nextDay));
        expect(InvalidTimeException.class, () -> cafe.endSession(cafe.getSessions().get(3),
                LocalDateTime.of(2026, 10, 5, 10, 59)));
        expect(SessionStateException.class, () -> cafe.issueReceipt("R05", cafe.getSessions().get(3),
                cafe.getEmployees().get(0)));
        expect(SessionStateException.class, () -> cafe.order("SV05", cafe.getSessions().get(0),
                cafe.getEmployees().get(0), LocalDateTime.of(2026, 10, 5, 9, 0),
                new Food[]{cafe.getFoods().get(0)}, new int[]{1}));
        expect(InvalidOrderException.class, () -> cafe.order("SV05", cafe.getSessions().get(3),
                cafe.getEmployees().get(0), LocalDateTime.of(2026, 10, 5, 11, 20),
                new Food[]{cafe.getFoods().get(0)}, new int[]{0}));
        expect(ReceiptAlreadyExistsException.class, () -> cafe.issueReceipt("R05", cafe.getSessions().get(0),
                cafe.getEmployees().get(0)));
        expect(PaymentAlreadyExistsException.class, () -> cafe.pay("P04", cafe.getReceipts().get(0),
                nextDay, PaymentMethod.CASH, cafe.getReceipts().get(0).getTotalAmount()));
        expect(PaymentAmountMismatchException.class, () -> cafe.pay("P04", cafe.getReceipts().get(1),
                nextDay, PaymentMethod.CASH, BigDecimal.ONE));
        expect(InvalidTimeException.class, () -> cafe.pay("P04", cafe.getReceipts().get(1),
                LocalDateTime.of(2026, 10, 5, 9, 0), PaymentMethod.CASH,
                cafe.getReceipts().get(1).getTotalAmount()));

        expect(ValidationException.class, () -> cafe.getComputerSectionDao().timKhuGiaCao(BigDecimal.ONE.negate()));
        expect(ValidationException.class, () -> cafe.getSessionDao().lichSuPhienTheoMay(" "));
        expect(EntityNotFoundException.class, () -> cafe.getSessionDao().lichSuPhienTheoMay("PC99"));
        expect(ValidationException.class, () -> cafe.getComputerDao().tongPhutChoiTheoMay(null));
        expect(ValidationException.class, () -> cafe.getSessionDao().tamTinhTienPhienDangChoi(null));
        if (!cafe.getSessionDao().tamTinhTienPhienDangChoi(LocalDateTime.of(2026, 10, 5, 10, 0)).isEmpty())
            throw new AssertionError("Phiên chưa mở không được xuất hiện trong báo cáo tạm tính");
        expect(EntityNotFoundException.class, () -> cafe.getSessionDao().lichSuPhienTheoKhach("C99"));
        expect(ValidationException.class, () -> cafe.getFoodDao().timMonTheoGia(BigDecimal.ONE.negate()));
        expect(EntityNotFoundException.class, () -> cafe.getFoodServiceDao().chiTietGoiMonTheoPhien("S99"));
        expect(ValidationException.class, () -> cafe.getFoodServiceDao().lanGoiMonVuotNguong(BigDecimal.ONE.negate()));
        expect(ValidationException.class, () -> cafe.getEmployeeDao().thongKeGoiMonTheoNhanVien(null));
        expect(ValidationException.class, () -> cafe.getFoodDao().monTonKhoThap(-1));

        // DAO getters may be used for reports, but writes must pass through a service.
        int paymentsBefore = cafe.getPayments().size();
        expect(ValidationException.class, () -> cafe.getPaymentDao().save(new Payment("P-direct",
                cafe.getReceipts().get(0), nextDay, PaymentMethod.CASH,
                cafe.getReceipts().get(0).getTotalAmount()), null));
        if (cafe.getPayments().size() != paymentsBefore)
            throw new AssertionError("Direct DAO write changed payments");
        Session active = cafe.getSessions().get(3);
        int activeOrdersBefore = active.getFoodServices().size();
        FoodService unregistered = new FoodService("SV-direct", active, cafe.getEmployees().get(0),
                LocalDateTime.of(2026, 10, 5, 11, 30),
                java.util.Collections.singletonMap(cafe.getFoods().get(0), 1));
        expect(InvalidOrderException.class, () -> active.recordFoodService(unregistered, null));
        if (active.getFoodServices().size() != activeOrdersBefore)
            throw new AssertionError("Direct session mutation changed orders");
        int stockBeforeDirect = cafe.getFoods().get(0).getStockQuantity();
        expect(ValidationException.class, () -> cafe.getFoods().get(0).restock(1, null));
        expect(InvalidOrderException.class, () -> cafe.getFoods().get(0).reduceStock(1, null));
        if (cafe.getFoods().get(0).getStockQuantity() != stockBeforeDirect)
            throw new AssertionError("Direct food mutation changed stock");
        expect(ValidationException.class, () -> cafe.getComputers().get(0)
                .setComputerStatus(ComputerStatus.IN_USE, null));
        NetCafe otherCafe = new NetCafe();
        expect(ValidationException.class, () -> otherCafe.addFood(cafe.getFoods().get(0)));
        if (!otherCafe.getFoods().isEmpty())
            throw new AssertionError("Food from another cafe was stored before ownership check");

        // A midnight crossing contributes only the minutes inside each requested day.
        NetCafe edge = new NetCafe();
        ComputerSection section = new ComputerSection("K", "Khu test", new BigDecimal("12000"));
        edge.addSection(section);
        Computer pc1 = new Computer("PC1", section, ComputerStatus.AVAILABLE);
        Computer pc2 = new Computer("PC2", section, ComputerStatus.AVAILABLE);
        edge.addComputer(pc1);
        edge.addComputer(pc2);
        Employee worker = new Employee("E", "Nhân viên", EmployeeStatus.ACTIVE);
        edge.addEmployee(worker);
        Customer c1 = new Customer("C1", "Khách một");
        Customer c2 = new Customer("C2", "Khách hai");
        edge.addCustomer(c1);
        edge.addCustomer(c2);
        Session overnight = edge.openSession("S-night", c1, pc1, worker,
                LocalDateTime.of(2026, 10, 7, 23, 30));
        edge.endSession(overnight, LocalDateTime.of(2026, 10, 8, 0, 30));
        if (edge.getComputerDao().tongPhutChoiTheoMay(LocalDate.of(2026, 10, 7)).stream()
                .noneMatch(row -> row.equals("PC1 | 30 phút"))
                || edge.getComputerDao().tongPhutChoiTheoMay(LocalDate.of(2026, 10, 8)).stream()
                .noneMatch(row -> row.equals("PC1 | 30 phút")))
            throw new AssertionError("Overnight minutes were assigned to the wrong day");
        edge.openSession("S-early", c1, pc1, worker, LocalDateTime.of(2026, 10, 8, 9, 0));
        edge.openSession("S-late", c2, pc2, worker, LocalDateTime.of(2026, 10, 8, 11, 0));
        java.util.List<String> asOf = edge.getSessionDao().tamTinhTienPhienDangChoi(
                LocalDateTime.of(2026, 10, 8, 10, 0));
        if (asOf.size() != 1 || !asOf.get(0).startsWith("S-early |"))
            throw new AssertionError("As-of report did not skip the later session");

        if (!cafe.getComputerSectionDao().timKhuGiaCao(new BigDecimal("25000")).isEmpty())
            throw new AssertionError("Ngưỡng giá nhập chưa được sử dụng");
        if (cafe.getSessionDao().lichSuPhienTheoMay("PC03").stream().noneMatch(row -> row.startsWith("S02 |")))
            throw new AssertionError("Mã máy nhập chưa được sử dụng");
        if (cafe.getComputerDao().tongPhutChoiTheoMay(LocalDate.of(2026, 10, 7)).stream()
                .anyMatch(row -> !row.endsWith("0 phút")))
            throw new AssertionError("Ngày nhập chưa được sử dụng");

        // A failed action must not create a record or change the availability of PC06.
        if (cafe.getSessions().size() != 6 || cafe.getReceipts().size() != 4 || cafe.getPayments().size() != 3)
            throw new AssertionError("Failed action changed stored data");
        cafe.addCustomer(new Customer("C06", "Khách mới"));
        if (cafe.getCustomerDao().xuatKhachChuaTungChoi().stream().noneMatch(row -> row.startsWith("C06 |")))
            throw new AssertionError("DAO query did not see new customer");
        Food noodles = cafe.getFoods().get(0);
        Food drink = cafe.getFoods().get(1);
        int noodlesBefore = noodles.getStockQuantity();
        int drinkBefore = drink.getStockQuantity();
        int ordersBefore = cafe.getServices().size();
        if (cafe.getFoodDao().monTonKhoThap(5).stream().noneMatch(row -> row.startsWith("F03 |"))
                || cafe.getFoodDao().monTonKhoThap(5).stream().anyMatch(row -> row.startsWith("F01 |")))
            throw new AssertionError("Low-stock report did not use the entered threshold");
        LocalDateTime orderTime = LocalDateTime.of(2026, 10, 5, 11, 30);
        expect(InvalidOrderException.class, () -> cafe.order("SV05", cafe.getSessions().get(3),
                cafe.getEmployees().get(0), orderTime,
                new Food[]{noodles, drink}, new int[]{1, drinkBefore + 1}));
        expect(InvalidOrderException.class, () -> cafe.order("SV05", cafe.getSessions().get(3),
                cafe.getEmployees().get(0), orderTime,
                new Food[]{noodles, noodles}, new int[]{noodlesBefore, 1}));
        if (noodles.getStockQuantity() != noodlesBefore || drink.getStockQuantity() != drinkBefore
                || cafe.getServices().size() != ordersBefore)
            throw new AssertionError("Rejected food order changed stock or order list");
        netcafe.model.FoodService accepted = cafe.order("SV05", cafe.getSessions().get(3),
                cafe.getEmployees().get(0), orderTime,
                new Food[]{noodles, noodles}, new int[]{2, 3});
        if (noodles.getStockQuantity() != noodlesBefore - 5 || accepted.getDetails().size() != 1
                || accepted.getDetails().get(0).getOrderQuantity() != 5)
            throw new AssertionError("Repeated food lines were not merged or stock was not deducted");
        if (cafe.getFoodDao().monTonKhoThap(5).stream().noneMatch(row -> row.startsWith("F01 |")))
            throw new AssertionError("Low-stock report did not see the updated stock");
        cafe.restockFood(noodles, 4);
        if (noodles.getStockQuantity() != noodlesBefore - 1)
            throw new AssertionError("Restock did not add to current stock");
        expect(ValidationException.class, () -> cafe.restockFood(noodles, 0));
        if (noodles.getStockQuantity() != noodlesBefore - 1)
            throw new AssertionError("Invalid restock changed stock");
        System.out.println("Đã kiểm tra " + passed + " tình huống lỗi; DAO thấy dữ liệu mới và dữ liệu không đổi sau lỗi.");
    }
}

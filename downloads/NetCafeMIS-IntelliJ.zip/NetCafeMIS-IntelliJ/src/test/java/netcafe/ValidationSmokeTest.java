package netcafe;

import netcafe.Service.NetCafe;
import netcafe.enums.PaymentMethod;
import netcafe.exception.*;
import netcafe.model.NetSpecs.Food;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/** Business-rule checks using the same sample shown in the menu. No test library needed. */
public final class ValidationSmokeTest {
    private static int passed;

    private static void expect(Class<? extends RuntimeException> type, Runnable action) {
        try {
            action.run();
        } catch (RuntimeException error) {
            if (!type.isInstance(error)) throw new AssertionError("Expected " + type.getSimpleName()
                    + ", got " + error.getClass().getSimpleName(), error);
            passed++;
            return;
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }

    public static void main(String[] args) {
        try { System.setOut(new java.io.PrintStream(System.out, true, "UTF-8")); }
        catch (java.io.UnsupportedEncodingException error) { throw new IllegalStateException(error); }
        NetCafe cafe = SampleData.create();
        LocalDateTime nextDay = LocalDateTime.of(2026, 10, 7, 8, 0);

        expect(DuplicateIdException.class, () -> cafe.addCustomer(new Customer("C01", "Trùng mã")));
        expect(ValidationException.class, () -> cafe.addCustomer(new Customer("  ", "Tên")));
        expect(EntityNotFoundException.class, () -> cafe.openSession("S07", new Customer("C99", "Lạ"),
                cafe.getComputers().get(5), cafe.getEmployees().get(0), nextDay));
        expect(InactiveEmployeeException.class, () -> cafe.openSession("S07", cafe.getCustomers().get(4),
                cafe.getComputers().get(5), cafe.getEmployees().get(2), nextDay));
        expect(ComputerUnavailableException.class, () -> cafe.openSession("S07", cafe.getCustomers().get(4),
                cafe.getComputers().get(4), cafe.getEmployees().get(0), nextDay));
        expect(ActiveSessionExistsException.class, () -> cafe.openSession("S07", cafe.getCustomers().get(0),
                cafe.getComputers().get(5), cafe.getEmployees().get(0), nextDay));
        expect(InvalidTimeException.class, () -> cafe.endSession(cafe.getSessions().get(3),
                LocalDateTime.of(2026, 10, 5, 10, 59)));
        expect(SessionStateException.class, () -> cafe.issueReceipt("R05", cafe.getSessions().get(3),
                cafe.getEmployees().get(0)));
        expect(SessionStateException.class, () -> cafe.order("SV05", cafe.getSessions().get(0),
                cafe.getEmployees().get(0), LocalDateTime.of(2026, 10, 5, 9, 0),
                new Food[]{cafe.getFoods().get(0)}, new int[]{1}));
        expect(InvalidOrderException.class, () -> cafe.order("SV05", cafe.getSessions().get(3),
                cafe.getEmployees().get(0), LocalDateTime.of(2026, 10, 5, 11, 20),
                new Food[]{cafe.getFoods().get(0)}, new int[]{0}));
        expect(ReceiptAlreadyExistsException.class, () -> cafe.issueReceipt("R05", cafe.getSessions().get(0),
                cafe.getEmployees().get(0)));
        expect(PaymentAlreadyExistsException.class, () -> cafe.pay("P04", cafe.getReceipts().get(0),
                nextDay, PaymentMethod.CASH, cafe.getReceipts().get(0).getTotalAmount()));
        expect(PaymentAmountMismatchException.class, () -> cafe.pay("P04", cafe.getReceipts().get(1),
                nextDay, PaymentMethod.CASH, BigDecimal.ONE));
        expect(InvalidTimeException.class, () -> cafe.pay("P04", cafe.getReceipts().get(1),
                LocalDateTime.of(2026, 10, 5, 9, 0), PaymentMethod.CASH,
                cafe.getReceipts().get(1).getTotalAmount()));

        expect(ValidationException.class, () -> cafe.getComputerSectionDao().timKhuGiaCao(BigDecimal.ONE.negate()));
        expect(ValidationException.class, () -> cafe.getSessionDao().lichSuPhienTheoMay(" "));
        expect(EntityNotFoundException.class, () -> cafe.getSessionDao().lichSuPhienTheoMay("PC99"));
        expect(ValidationException.class, () -> cafe.getComputerDao().tongPhutChoiTheoMay(null));
        expect(ValidationException.class, () -> cafe.getSessionDao().tamTinhTienPhienDangChoi(null));
        expect(InvalidTimeException.class, () -> cafe.getSessionDao().tamTinhTienPhienDangChoi(
                LocalDateTime.of(2026, 10, 5, 10, 0)));
        expect(EntityNotFoundException.class, () -> cafe.getSessionDao().lichSuPhienTheoKhach("C99"));
        expect(ValidationException.class, () -> cafe.getFoodDao().timMonTheoGia(BigDecimal.ONE.negate()));
        expect(EntityNotFoundException.class, () -> cafe.getFoodServiceDao().chiTietGoiMonTheoPhien("S99"));
        expect(ValidationException.class, () -> cafe.getFoodServiceDao().lanGoiMonVuotNguong(BigDecimal.ONE.negate()));
        expect(ValidationException.class, () -> cafe.getEmployeeDao().thongKeGoiMonTheoNhanVien(null));

        if (!cafe.getComputerSectionDao().timKhuGiaCao(new BigDecimal("25000")).isEmpty())
            throw new AssertionError("Ngưỡng giá nhập chưa được sử dụng");
        if (cafe.getSessionDao().lichSuPhienTheoMay("PC03").stream().noneMatch(row -> row.startsWith("S02 |")))
            throw new AssertionError("Mã máy nhập chưa được sử dụng");
        if (cafe.getComputerDao().tongPhutChoiTheoMay(LocalDate.of(2026, 10, 7)).stream()
                .anyMatch(row -> !row.endsWith("0 phút")))
            throw new AssertionError("Ngày nhập chưa được sử dụng");

        // A failed action must not create a record or change the availability of PC06.
        if (cafe.getSessions().size() != 6 || cafe.getReceipts().size() != 4 || cafe.getPayments().size() != 3)
            throw new AssertionError("Failed action changed stored data");
        cafe.addCustomer(new Customer("C06", "Khách mới"));
        if (cafe.getCustomerDao().xuatKhachChuaTungChoi().stream().noneMatch(row -> row.startsWith("C06 |")))
            throw new AssertionError("DAO query did not see new customer");
        System.out.println("Đã kiểm tra " + passed + " tình huống lỗi; DAO thấy dữ liệu mới và dữ liệu không đổi sau lỗi.");
    }
}

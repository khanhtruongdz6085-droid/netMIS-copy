package netcafe.dao;

import netcafe.model.FoodService;
import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static netcafe.dao.DaoQuerySupport.*;

/** Access to payments stored in memory. */
public final class PaymentDao extends MemoryDao<Payment> {
    private final DaoQueryContext context;

    public PaymentDao(DaoQueryContext context) { this.context = context; }

    public Optional<Payment> findByReceipt(Receipt receipt) {
        return stream().filter(payment -> payment.getReceipt() == receipt).findFirst();
    }

    public List<String> doanhThuTheoNgay() {
        Map<LocalDate, BigDecimal> totals = stream().collect(Collectors.groupingBy(
            p -> p.getTime().toLocalDate(), Collectors.reducing(BigDecimal.ZERO, Payment::getAmount, BigDecimal::add)));
        return totals.entrySet().stream().sorted(Map.Entry.comparingByKey())
            .map(e -> e.getKey() + " | " + money(e.getValue())).collect(Collectors.toList());
    }

    public List<String> thongKeThanhToanTheoPhuongThuc() {
        return Arrays.stream(PaymentMethod.values()).map(method -> {
            List<Payment> payments = stream().filter(p -> p.getPaymentMethod() == method)
                .collect(Collectors.toList());
            return method + " | " + payments.size() + " | " + money(sum(payments.stream()
                .map(Payment::getAmount).collect(Collectors.toList())));
        }).collect(Collectors.toList());
    }

    public List<String> topKhachThanhToanNhieuNhat() {
        Map<Customer, BigDecimal> totals = stream().collect(Collectors.groupingBy(
            p -> customer(p.getReceipt().getSession()),
            Collectors.reducing(BigDecimal.ZERO, Payment::getAmount, BigDecimal::add)));
        return totals.entrySet().stream().sorted(Comparator
            .comparing((Map.Entry<Customer, BigDecimal> e) -> e.getValue()).reversed()
            .thenComparing(e -> e.getKey().getId())).limit(3)
            .map(e -> e.getKey().getId() + " | " + e.getKey().getName() + " | " + money(e.getValue()))
            .collect(Collectors.toList());
    }
}

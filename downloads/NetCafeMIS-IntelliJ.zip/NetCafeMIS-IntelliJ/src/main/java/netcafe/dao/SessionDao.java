package netcafe.dao;

import netcafe.model.FoodService;
import netcafe.enums.*;
import netcafe.exception.InvalidTimeException;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static netcafe.dao.DaoQuerySupport.*;

/** Access to sessions stored in memory. */
public final class SessionDao extends MemoryDao<Session> {
    private final DaoQueryContext context;

    public SessionDao(DaoQueryContext context) { this.context = context; }

    public List<Session> findByCustomer(Customer customer) {
        return stream().filter(session -> session.getCustomer() == customer).collect(Collectors.toList());
    }

    public List<Session> findByComputer(Computer computer) {
        return stream().filter(session -> session.getComputer() == computer).collect(Collectors.toList());
    }

    public List<Session> findByStatus(SessionStatus status) {
        return stream().filter(session -> session.getSessionStatus() == status).collect(Collectors.toList());
    }

    public List<String> lichSuPhienTheoMay(String maMay) {
        String id = existingId(maMay, context.getComputers(), "Máy");
        return stream().filter(s -> s.getComputer().getId().equals(id))
            .sorted(Comparator.comparing(Session::getTimeStart).reversed())
            .map(s -> s.getId() + " | " + customer(s).getName() + " | " + s.getTimeStart() + " | "
                + s.getTimeEnd() + " | " + s.getSessionStatus() + " | " + s.getOpenedBy().getEmployeeName())
            .collect(Collectors.toList());
    }

    public List<String> lietKePhienDangChoi() {
        return stream().filter(s -> s.getSessionStatus() == SessionStatus.ACTIVE)
            .sorted(Comparator.comparing(Session::getId))
            .map(s -> s.getId() + " | " + customer(s).getName() + " | " + s.getComputer().getId()
                + " | " + s.getComputer().getSection().getSectionName() + " | " + s.getTimeStart()
                + " | " + s.getOpenedBy().getEmployeeName())
            .collect(Collectors.toList());
    }

    public List<String> phienChoiTu120Phut() {
        return stream().filter(s -> s.getSessionStatus() == SessionStatus.COMPLETED)
            .filter(s -> Duration.between(s.getTimeStart(), s.getTimeEnd()).toMinutes() >= 120)
            .sorted(Comparator.comparingLong((Session s) -> Duration.between(s.getTimeStart(), s.getTimeEnd()).toMinutes()).reversed())
            .map(s -> s.getId() + " | " + Duration.between(s.getTimeStart(), s.getTimeEnd()).toMinutes() + " phút")
            .collect(Collectors.toList());
    }

    public List<String> tamTinhTienPhienDangChoi(LocalDateTime thoiDiem) {
        requireMoment(thoiDiem);
        if (stream().anyMatch(s -> s.getSessionStatus() == SessionStatus.ACTIVE
                && thoiDiem.isBefore(s.getTimeStart())))
            throw new InvalidTimeException("Thời điểm tính tiền không được trước giờ mở phiên đang chơi");
        return stream().filter(s -> s.getSessionStatus() == SessionStatus.ACTIVE)
            .filter(s -> !thoiDiem.isBefore(s.getTimeStart())).sorted(Comparator.comparing(Session::getId))
            .map(s -> s.getId() + " | " + money(s.amountAt(thoiDiem))).collect(Collectors.toList());
    }

    public List<String> lichSuPhienTheoKhach(String maKhach) {
        String id = existingId(maKhach, context.getCustomers(), "Khách");
        return stream().filter(s -> customer(s).getId().equals(id))
            .sorted(Comparator.comparing(Session::getTimeStart).reversed())
            .map(s -> s.getId() + " | " + s.getComputer().getId() + " | " + s.getSessionStatus()
                + " | " + s.getTimeStart()).collect(Collectors.toList());
    }

    public List<String> tongTienMonTheoPhien() {
        return stream()
            .sorted(Comparator.comparing((Session s) -> sum(context.getServices().stream().filter(x -> x.getSession() == s)
                .map(FoodService::getTotal).collect(Collectors.toList()))).reversed().thenComparing(Session::getId))
            .map(s -> s.getId() + " | " + money(sum(context.getServices().stream().filter(x -> x.getSession() == s)
                .map(FoodService::getTotal).collect(Collectors.toList())))).collect(Collectors.toList());
    }

    public List<String> phienHoanTatKhongGoiMon() {
        return stream().filter(s -> s.getSessionStatus() == SessionStatus.COMPLETED)
            .filter(s -> context.getServices().stream().noneMatch(x -> x.getSession() == s))
            .map(Session::getId).collect(Collectors.toList());
    }

    public List<String> phienHoanTatChuaCoHoaDon() {
        return stream().filter(s -> s.getSessionStatus() == SessionStatus.COMPLETED)
            .filter(s -> context.getReceipts().stream().noneMatch(r -> r.getSession() == s))
            .map(s -> s.getId() + " | " + customer(s).getName()).collect(Collectors.toList());
    }
}

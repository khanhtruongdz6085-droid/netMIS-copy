package netcafe.dao;

import netcafe.model.FoodService;
import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static netcafe.dao.DaoQuerySupport.*;

/** Access to computers stored in memory. */
public final class ComputerDao extends MemoryDao<Computer> {
    private final DaoQueryContext context;

    public ComputerDao(DaoQueryContext context) { this.context = context; }

    public List<Computer> findBySection(ComputerSection section) {
        return stream().filter(computer -> computer.getSection() == section).collect(Collectors.toList());
    }

    public List<Computer> findByStatus(ComputerStatus status) {
        return stream().filter(computer -> computer.getComputerStatus() == status).collect(Collectors.toList());
    }

    public List<String> lietKeMayTrong() {
        return stream().filter(x -> x.getComputerStatus() == ComputerStatus.AVAILABLE)
            .sorted(Comparator.comparing((Computer x) -> x.getSection().getSectionPrice()).thenComparing(Computer::getId))
            .map(x -> x.getId() + " | " + x.getSection().getSectionName() + " | " + money(x.getSection().getSectionPrice()))
            .collect(Collectors.toList());
    }

    public List<String> lietKeMayBaoTri() {
        return stream().filter(x -> x.getComputerStatus() == ComputerStatus.MAINTENANCE)
            .sorted(Comparator.comparing(Computer::getId))
            .map(x -> x.getId() + " | " + x.getSection().getSectionName()).collect(Collectors.toList());
    }

    public List<String> tongPhutChoiTheoMay(LocalDate ngay) {
        requireDate(ngay);
        return stream().sorted(Comparator.comparing(Computer::getId))
            .map(x -> x.getId() + " | " + context.getSessions().stream()
                .filter(s -> s.getComputer() == x && s.getSessionStatus() == SessionStatus.COMPLETED
                    && s.getTimeStart().toLocalDate().equals(ngay))
                .mapToLong(s -> Duration.between(s.getTimeStart(), s.getTimeEnd()).toMinutes()).sum() + " phút")
            .collect(Collectors.toList());
    }

    public List<String> mayChuaTungDuocSuDung() {
        return stream().filter(x -> context.getSessions().stream().noneMatch(s -> s.getComputer() == x))
            .sorted(Comparator.comparing(Computer::getId)).map(Computer::getId).collect(Collectors.toList());
    }
}

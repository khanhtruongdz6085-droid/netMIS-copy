package netcafe.dao;

import netcafe.model.FoodService;
import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static netcafe.dao.DaoQuerySupport.*;

/** Access to food orders stored in memory. */
public final class FoodServiceDao extends MemoryDao<FoodService> {
    private final DaoQueryContext context;

    public FoodServiceDao(DaoQueryContext context) { this.context = context; }

    public List<FoodService> findBySession(Session session) {
        return stream().filter(order -> order.getSession() == session).collect(Collectors.toList());
    }

    public List<String> chiTietGoiMonTheoPhien(String maPhien) {
        String id = existingId(maPhien, context.getSessions(), "Phiên");
        return stream().filter(s -> s.getSession().getId().equals(id))
            .flatMap(s -> s.getDetails().stream().map(d -> s.getId() + " | " + s.getEmployee().getEmployeeName()
                + " | " + d.getFood().getFoodName() + " | " + d.getOrderQuantity() + " | "
                + money(d.getPriceAtOrder()) + " | " + money(d.calculateAmount())))
            .collect(Collectors.toList());
    }

    public List<String> lanGoiMonVuotNguong(BigDecimal nguongTien) {
        nonNegative(nguongTien, "Ngưỡng tiền gọi món");
        return stream().filter(s -> s.getTotal().compareTo(nguongTien) > 0)
            .sorted(Comparator.comparing(FoodService::getId))
            .map(s -> s.getId() + " | " + customer(s.getSession()).getName() + " | " + money(s.getTotal()))
            .collect(Collectors.toList());
    }
}

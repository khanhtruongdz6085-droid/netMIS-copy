package netcafe.dao;

import netcafe.model.FoodService;
import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static netcafe.dao.DaoQuerySupport.*;

/** Access to receipts stored in memory. */
public final class ReceiptDao extends MemoryDao<Receipt> {
    private final DaoQueryContext context;

    public ReceiptDao(DaoQueryContext context) { this.context = context; }

    public Optional<Receipt> findBySession(Session session) {
        return stream().filter(receipt -> receipt.getSession() == session).findFirst();
    }

    public List<String> hoaDonChuaThanhToan() {
        return stream().filter(r -> !paid(r, context)).sorted(Comparator.comparing(Receipt::getId))
            .map(r -> r.getId() + " | " + customer(r.getSession()).getName() + " | "
                + r.getEmployee().getEmployeeName() + " | " + money(r.getTotalAmount())).collect(Collectors.toList());
    }

    public List<String> hoaDonGiaTriLonNhat() {
        BigDecimal max = stream().map(Receipt::getTotalAmount)
            .max(BigDecimal::compareTo).orElse(BigDecimal.ZERO);
        return stream().filter(r -> r.getTotalAmount().compareTo(max) == 0)
            .map(r -> r.getId() + " | " + customer(r.getSession()).getName() + " | "
                + r.getSession().getId() + " | " + money(r.getTotalAmount())).collect(Collectors.toList());
    }

    public List<String> hoaDonThanhToanSaiLech() {
        return stream().map(r -> {
            List<Payment> payments = context.getPayments().stream().filter(p -> p.getReceipt() == r).collect(Collectors.toList());
            List<String> reasons = new ArrayList<>();
            if (payments.size() > 1) reasons.add("nhiều thanh toán");
            if (payments.stream().anyMatch(p -> p.getAmount().compareTo(r.getTotalAmount()) != 0))
                reasons.add("sai số tiền");
            return reasons.isEmpty() ? null : r.getId() + " | " + String.join(", ", reasons);
        }).filter(Objects::nonNull).collect(Collectors.toList());
    }
}

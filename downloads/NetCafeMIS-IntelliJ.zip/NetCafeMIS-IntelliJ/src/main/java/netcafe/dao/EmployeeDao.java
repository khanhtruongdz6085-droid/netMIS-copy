package netcafe.dao;

import netcafe.model.FoodService;
import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static netcafe.dao.DaoQuerySupport.*;

/** Access to employees stored in memory. */
public final class EmployeeDao extends MemoryDao<Employee> {
    private final DaoQueryContext context;

    public EmployeeDao(DaoQueryContext context) { this.context = context; }

    public List<Employee> findByStatus(EmployeeStatus status) {
        return stream().filter(employee -> employee.getEmployeeStatus() == status).collect(Collectors.toList());
    }

    public List<String> thongKeGoiMonTheoNhanVien(LocalDate ngay) {
        requireDate(ngay);
        return stream().sorted(Comparator.comparing(Employee::getId))
            .map(e -> {
                List<FoodService> orders = context.getServices().stream().filter(s -> s.getEmployee() == e
                    && s.getTimeStartService().toLocalDate().equals(ngay)).collect(Collectors.toList());
                return e.getId() + " | " + orders.size() + " | " + money(sum(orders.stream()
                    .map(FoodService::getTotal).collect(Collectors.toList())));
            }).collect(Collectors.toList());
    }

    public List<String> giaTriHoaDonTheoNhanVien() {
        return stream().sorted(Comparator.comparing(Employee::getId)).map(e -> {
            List<Receipt> receipts = context.getReceipts().stream().filter(r -> r.getEmployee() == e)
                .collect(Collectors.toList());
            BigDecimal all = sum(receipts.stream().map(Receipt::getTotalAmount).collect(Collectors.toList()));
            BigDecimal received = sum(receipts.stream().filter(r -> paid(r, context))
                .map(Receipt::getTotalAmount).collect(Collectors.toList()));
            return e.getId() + " | " + receipts.size() + " | " + money(all) + " | "
                + money(received) + " | " + money(all.subtract(received));
        }).collect(Collectors.toList());
    }
}

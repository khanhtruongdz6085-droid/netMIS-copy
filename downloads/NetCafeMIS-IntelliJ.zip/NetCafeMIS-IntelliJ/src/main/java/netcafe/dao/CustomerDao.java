package netcafe.dao;

import netcafe.model.FoodService;
import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static netcafe.dao.DaoQuerySupport.*;

/** Access to customers stored in memory. */
public final class CustomerDao extends MemoryDao<Customer> {
    private final DaoQueryContext context;

    public CustomerDao(DaoQueryContext context) { this.context = context; }

    public Optional<Customer> findByName(String name) {
        return stream().filter(customer -> customer.getName().equalsIgnoreCase(name)).findFirst();
    }

    public List<Customer> xuatKhachDangChoi() {
        return stream().filter(khach -> context.getSessions().stream()
            .anyMatch(phien -> phien.getCustomer() == khach
                && phien.getSessionStatus() == SessionStatus.ACTIVE))
            .collect(Collectors.toList());
    }

    public List<String> xuatKhachChuaTungChoi() {
        return stream().filter(x -> context.getSessions().stream().noneMatch(s -> customer(s) == x))
            .map(x -> x.getId() + " | " + x.getName()).collect(Collectors.toList());
    }

    public List<String> demPhienHoanTatTheoKhach() {
        return stream()
            .sorted(Comparator.comparingLong((Customer x) -> context.getSessions().stream()
                .filter(s -> customer(s) == x && s.getSessionStatus() == SessionStatus.COMPLETED).count())
                .reversed().thenComparing(Customer::getId))
            .map(x -> x.getId() + " | " + context.getSessions().stream()
                .filter(s -> customer(s) == x && s.getSessionStatus() == SessionStatus.COMPLETED).count())
            .collect(Collectors.toList());
    }

    public List<String> tienConThuTheoKhach() {
        return stream().map(x -> new AbstractMap.SimpleEntry<>(x,
            sum(context.getReceipts().stream().filter(r -> customer(r.getSession()) == x && !paid(r, context))
                .map(Receipt::getTotalAmount).collect(Collectors.toList()))))
            .filter(e -> e.getValue().signum() > 0).sorted(Comparator.comparing(e -> e.getKey().getId()))
            .map(e -> e.getKey().getId() + " | " + money(e.getValue())).collect(Collectors.toList());
    }
}

package netcafe.model;
import netcafe.Chargeable;
import netcafe.Identifiable;
import netcafe.model.FoodService;
import netcafe.enums.ComputerStatus;
import netcafe.enums.SessionStatus;
import netcafe.exception.DuplicateIdException;
import netcafe.exception.InvalidOrderException;
import netcafe.exception.InvalidTimeException;
import netcafe.exception.SessionStateException;
import netcafe.model.NetSpecs.Computer;
import netcafe.model.NetSpecs.Employee;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Session implements Identifiable, Chargeable {
  // Attribute
  private final String sessionId;
  private final Customer customer;
  private final Computer computer;
  private final Employee openedBy;
  private final LocalDateTime timeStart;
  private final List<FoodService> foodServices = new ArrayList<>();
  private LocalDateTime timeEnd;
  private SessionStatus sessionStatus;

  //Constructor
  public Session(String id, Customer customer, Computer computer, Employee openedBy, LocalDateTime start) {
    sessionId=Checks.id(id);
    this.customer=Checks.required(customer, "customer");
    this.computer=Checks.required(computer, "computer");
    this.openedBy=Checks.required(openedBy, "openedBy");
    timeStart=Checks.required(start, "start");
    sessionStatus=SessionStatus.ACTIVE;
  }

  public String getId() { return sessionId; }
  public String getSessionId() { return sessionId; }
  public Customer getCustomer() { return customer; }
  public Computer getComputer() { return computer; }
  public Employee getOpenedBy() { return openedBy; }
  public LocalDateTime getTimeStart() { return timeStart; }
  public LocalDateTime getTimeEnd() { return timeEnd; }
  public SessionStatus getSessionStatus() { return sessionStatus; }
  public List<FoodService> getFoodServices() { return Collections.unmodifiableList(foodServices); }

  /** Validate and lock an order before linking it to this session. */
  public void recordFoodService(FoodService service) {
    Checks.required(service, "foodService");
    if (sessionStatus != SessionStatus.ACTIVE) throw new SessionStateException("Chỉ được gọi món khi phiên đang hoạt động: " + sessionId);
    if (service.getSession() != this) throw new InvalidOrderException("Lần gọi món thuộc phiên khác");
    if (service.getTimeStartService().isBefore(timeStart)) throw new InvalidTimeException("Giờ gọi món trước giờ mở phiên");
    for (FoodService old : foodServices) {
      if (old.getId().equals(service.getId())) throw new DuplicateIdException("Mã lần gọi món đã tồn tại: " + service.getId());
    }
    service.seal();
    foodServices.add(service);
  }

  /** Both direct callers and SessionService use these completion rules. */
  public void endSession(LocalDateTime end) {
    if (sessionStatus != SessionStatus.ACTIVE) throw new SessionStateException("Phiên đã kết thúc: " + sessionId);
    if (end == null || !end.isAfter(timeStart)) throw new InvalidTimeException("Giờ kết thúc phải sau giờ mở phiên: " + sessionId);
    for (FoodService service : foodServices) {
      if (service.getTimeStartService().isAfter(end)) throw new InvalidTimeException("Có lần gọi món sau giờ kết thúc dự kiến");
    }
    timeEnd=end; sessionStatus=SessionStatus.COMPLETED;
    computer.setComputerStatus(ComputerStatus.AVAILABLE);
  }
  public BigDecimal amountAt(LocalDateTime at) {
    if (at == null || at.isBefore(timeStart)) throw new InvalidTimeException("Thời điểm tính tiền thiếu hoặc trước giờ mở phiên: " + sessionId);
    long seconds=Duration.between(timeStart, at).getSeconds();
    return computer.getSection().getSectionPrice().multiply(BigDecimal.valueOf(seconds)).divide(BigDecimal.valueOf(3600), 0, RoundingMode.HALF_UP);
  }
  public BigDecimal calculateAmount() {
    if (timeEnd == null) throw new SessionStateException("Chưa thể chốt tiền khi phiên đang hoạt động: " + sessionId);
    return amountAt(timeEnd);
  }
}

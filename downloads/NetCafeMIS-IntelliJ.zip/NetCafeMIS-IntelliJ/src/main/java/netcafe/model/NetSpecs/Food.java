package netcafe.model.NetSpecs;
import netcafe.Identifiable;
import netcafe.model.Checks;

import java.math.BigDecimal;
public final class Food implements Identifiable {
  // Attribute
  private final String foodId, foodName;
  private final BigDecimal price;

  // Constructor
  public Food(String id, String name, BigDecimal price) {
    foodId= Checks.id(id);
    foodName=Checks.name(name);
    this.price=Checks.money(price); }

  public String getId() { return foodId; }
  public String getFoodId() { return foodId; }
  public String getFoodName() { return foodName; }
  public BigDecimal getPrice() { return price; }
}

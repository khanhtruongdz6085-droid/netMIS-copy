package netcafe.model;
import netcafe.Chargeable;
import netcafe.model.FoodService;
import netcafe.exception.InvalidOrderException;
import netcafe.model.NetSpecs.Food;

import java.math.BigDecimal;

public final class FoodOrderDetail implements Chargeable {
  // Attribute
  private final FoodService service;
  private final Food food;
  private int orderQuantity;
  private final BigDecimal priceAtOrder;

  // Constructor
  public FoodOrderDetail(FoodService service, Food food, int quantity, BigDecimal price) {
    this.service=Checks.  required(service, "service");
    this.food=Checks.required(food, "food");
    if (quantity <= 0)
      throw new InvalidOrderException("Số lượng món phải lớn hơn 0");
    orderQuantity=quantity;
    priceAtOrder=Checks.money(price);
  }

  public void addQuantity(int quantity) {
    if (service.isSealed())
      throw new InvalidOrderException("Lần gọi món đã ghi nhận, không thể sửa: " + service.getId());
    if (quantity <= 0 || orderQuantity > Integer.MAX_VALUE - quantity)
      throw new InvalidOrderException("Số lượng món phải dương và không vượt giới hạn số nguyên");
    orderQuantity += quantity;
  }
  // Getter
  public FoodService getService() { return service; }
  public Food getFood() { return food; }
  public int getOrderQuantity() { return orderQuantity; }
  public BigDecimal getPriceAtOrder() { return priceAtOrder; }
  public BigDecimal calculateAmount() {
    return priceAtOrder.multiply(BigDecimal.valueOf(orderQuantity)); }
}

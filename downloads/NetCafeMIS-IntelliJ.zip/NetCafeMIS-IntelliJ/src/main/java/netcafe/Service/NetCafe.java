package netcafe.Service;

import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
/** Provides one shared data context and its business services. */
public final class NetCafe {
    // Attribute
    private final NetCafeData data = new NetCafeData();
    private final CatalogService catalogService = new CatalogService(data);
    private final SessionService sessionService = new SessionService(data);
    private final FoodOrderService foodOrderService = new FoodOrderService(data);
    private final ReceiptService receiptService = new ReceiptService(data);
    private final PaymentService paymentService = new PaymentService(data);

    // Getter
    public CatalogService getCatalogService() { return catalogService; }
    public SessionService getSessionService() { return sessionService; }
    public FoodOrderService getFoodOrderService() { return foodOrderService; }
    public ReceiptService getReceiptService() { return receiptService; }
    public PaymentService getPaymentService() { return paymentService; }

    // Method
    public void addSection(ComputerSection value) { catalogService.addSection(value); }
    public void addComputer(Computer value) { catalogService.addComputer(value); }
    public void addCustomer(Customer value) { catalogService.addCustomer(value); }
    public void addEmployee(Employee value) { catalogService.addEmployee(value); }
    public void addFood(Food value) { catalogService.addFood(value); }

    public Session openSession(String id, Customer customer, Computer computer, Employee openedBy, LocalDateTime start) {
        return sessionService.openSession(id, customer, computer, openedBy, start);
    }

    public void endSession(Session session, LocalDateTime end) {
        sessionService.endSession(session, end);
    }

    public FoodService order(String id, Session session, Employee employee, LocalDateTime time,
                             Food[] items, int[] quantities) {
        return foodOrderService.order(id, session, employee, time, items, quantities);
    }

    public FoodService order(String id, Session session, Employee employee, LocalDateTime time,
                             Food[] items, int[] quantities, BigDecimal[] prices) {
        return foodOrderService.order(id, session, employee, time, items, quantities, prices);
    }

    public Receipt issueReceipt(String id, Session session, Employee employee) {
        return receiptService.issueReceipt(id, session, employee);
    }

    public Payment pay(String id, Receipt receipt, LocalDateTime time, PaymentMethod method, BigDecimal amount) {
        return paymentService.pay(id, receipt, time, method, amount);
    }

    public BigDecimal collectedAmount() { return paymentService.collectedAmount(); }

    public netcafe.dao.ComputerSectionDao getComputerSectionDao() { return data.sections; }
    public netcafe.dao.ComputerDao getComputerDao() { return data.computers; }
    public netcafe.dao.CustomerDao getCustomerDao() { return data.customers; }
    public netcafe.dao.EmployeeDao getEmployeeDao() { return data.employees; }
    public netcafe.dao.FoodDao getFoodDao() { return data.foods; }
    public netcafe.dao.SessionDao getSessionDao() { return data.sessions; }
    public netcafe.dao.FoodServiceDao getFoodServiceDao() { return data.services; }
    public netcafe.dao.ReceiptDao getReceiptDao() { return data.receipts; }
    public netcafe.dao.PaymentDao getPaymentDao() { return data.payments; }

    public List<ComputerSection> getSections() { return data.sections.findAll(); }
    public List<Computer> getComputers() { return data.computers.findAll(); }
    public List<Customer> getCustomers() { return data.customers.findAll(); }
    public List<Employee> getEmployees() { return data.employees.findAll(); }
    public List<Food> getFoods() { return data.foods.findAll(); }
    public List<Session> getSessions() { return data.sessions.findAll(); }
    public List<FoodService> getServices() { return data.services.findAll(); }
    public List<Receipt> getReceipts() { return data.receipts.findAll(); }
    public List<Payment> getPayments() { return data.payments.findAll(); }
}


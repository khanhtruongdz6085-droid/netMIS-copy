package netcafe.Service;

import netcafe.Identifiable;
import netcafe.dao.MemoryDao;
import netcafe.enums.EmployeeStatus;
import netcafe.exception.*;
import netcafe.model.NetSpecs.Employee;

/** Validation helpers internal to the service package. */
final class ServiceChecks {
    private ServiceChecks() {}

    static <T> T required(T value, String field) {
        if (value == null) throw new ValidationException("Thiếu dữ liệu: " + field);
        return value;
    }

    static <T extends Identifiable> void unique(MemoryDao<T> list, String id) {
        if (id == null || id.trim().isEmpty()) throw new ValidationException("Mã ID không được để trống");
        if (list.findById(id.trim()).isPresent()) throw new DuplicateIdException("Mã đã tồn tại: " + id);
    }

    static <T extends Identifiable> void add(MemoryDao<T> list, T value) {
        required(value, "entity");
        list.save(value);
    }

    static <T extends Identifiable> void registered(MemoryDao<T> list, T value) {
        required(value, "reference");
        if (!list.contains(value)) throw new EntityNotFoundException("Dữ liệu liên kết chưa được thêm vào hệ thống");
    }

    static void activeEmployee(Employee employee) {
        if (employee.getEmployeeStatus() != EmployeeStatus.ACTIVE) {
            throw new InactiveEmployeeException("Nhân viên đang ngừng hoạt động: " + employee.getId());
        }
    }
}


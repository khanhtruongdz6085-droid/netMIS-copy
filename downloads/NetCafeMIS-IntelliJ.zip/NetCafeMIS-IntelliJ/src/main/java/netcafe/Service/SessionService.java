package netcafe.Service;

import netcafe.enums.*;
import netcafe.exception.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.Computer;
import netcafe.model.NetSpecs.Employee;
import netcafe.model.customer.Customer;

import java.time.LocalDateTime;

import static netcafe.Service.ServiceChecks.*;

public final class SessionService {
    private final NetCafeData data;

    SessionService(NetCafeData data) {
        this.data = data;
    }

    public Session openSession(String id, Customer customer, Computer computer, Employee openedBy, LocalDateTime start) {
        unique(data.sessions, id);
        registered(data.customers, customer);
        registered(data.computers, computer);
        registered(data.employees, openedBy);
        activeEmployee(openedBy);
        if (start == null) throw new InvalidTimeException("Thiếu thời gian bắt đầu phiên");
        if (computer.getComputerStatus() != ComputerStatus.AVAILABLE) {
            throw new ComputerUnavailableException("Máy không sẵn sàng: " + computer.getId());
        }
        for (Session old : data.sessions.findByCustomer(customer)) {
            if (old.getSessionStatus() == SessionStatus.ACTIVE) {
                throw new ActiveSessionExistsException("Khách đang có phiên: " + customer.getId());
            }
            if (old.getTimeEnd() == null || old.getTimeEnd().isAfter(start)) {
                throw new InvalidTimeException("Phiên chồng lấn lịch sử hoặc bắt đầu trước phiên cũ kết thúc");
            }
        }
        for (Session old : data.sessions.findByComputer(computer)) {
            if (old.getTimeEnd() == null || old.getTimeEnd().isAfter(start))
                throw new InvalidTimeException("Phiên chồng lấn lịch sử hoặc bắt đầu trước phiên cũ kết thúc");
        }
        Session session = new Session(id, customer, computer, openedBy, start);
        data.sessions.save(session);
        computer.setComputerStatus(ComputerStatus.IN_USE);
        return session;
    }

    public void endSession(Session session, LocalDateTime end) {
        registered(data.sessions, session);
        session.endSession(end);
    }
}


package netcafe;

import netcafe.Service.NetCafe;
import netcafe.enums.ComputerStatus;
import netcafe.enums.EmployeeStatus;
import netcafe.enums.PaymentMethod;
import netcafe.exception.*;
import netcafe.model.Payment;
import netcafe.model.Receipt;
import netcafe.model.Session;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

/** Interactive Java menu. All changes stay in the same NetCafe instance until exit. */
public final class ConsoleMenu {
    private final NetCafe cafe;
    private final ConsoleInput input;
    private final ReportMenu reports;

    public ConsoleMenu(NetCafe cafe, Scanner input) {
        this.cafe = cafe;
        this.input = new ConsoleInput(input);
        this.reports = new ReportMenu(cafe, this.input);
    }

    public void run() {
        System.out.println("NETCAFE MIS | MENU JAVA | dữ liệu mẫu đã được nạp");
        while (true) {
            printMenu();
            String choice = input.line("Chọn chức năng: ");
            if (choice == null || "0".equals(choice.trim())) {
                System.out.println("Đã thoát. Dữ liệu List chỉ tồn tại trong lần chạy này.");
                return;
            }
            try {
                execute(choice.trim());
            } catch (RuntimeException error) {
                System.out.println("LỖI: " + errorMessage(error));
            }
        }
    }

    private void printMenu() {
        System.out.println("\n=== CHỨC NĂNG ===");
        System.out.println(" 1. Xem dữ liệu hiện có       2. Tra cứu theo mã");
        System.out.println(" 3. Thêm khu máy              4. Thêm máy tính");
        System.out.println(" 5. Thêm khách                6. Thêm nhân viên");
        System.out.println(" 7. Thêm món                  8. Mở phiên");
        System.out.println(" 9. Kết thúc phiên           10. Gọi món");
        System.out.println("11. Lập hóa đơn             12. Thanh toán");
        System.out.println("13. Chạy một truy vấn        14. Chạy nhóm 10 truy vấn");
        System.out.println("15. Chạy toàn bộ 30 truy vấn 16. Khách đang chơi  0. Thoát");
    }

    private void execute(String choice) {
        switch (choice) {
            case "1": showAll(); break;
            case "2": search(); break;
            case "3": addSection(); break;
            case "4": addComputer(); break;
            case "5": addCustomer(); break;
            case "6": addEmployee(); break;
            case "7": addFood(); break;
            case "8": openSession(); break;
            case "9": endSession(); break;
            case "10": orderFood(); break;
            case "11": issueReceipt(); break;
            case "12": pay(); break;
            case "13": reports.runOne(); break;
            case "14": reports.runGroup(); break;
            case "15": reports.runAll(); break;
            case "16": cafe.getCustomerDao().xuatKhachDangChoi().forEach(khach ->
                System.out.println(khach.getId() + " | " + khach.getName())); break;
            default: System.out.println("LỖI: Chức năng không tồn tại. Chọn từ 0 đến 16.");
        }
    }

    private void addSection() {
        String id = input.required("Mã khu: ");
        String name = input.required("Tên khu: ");
        BigDecimal price = input.money("Giá một giờ (đồng): ");
        cafe.addSection(new ComputerSection(id, name, price));
        System.out.println("Đã thêm khu " + id);
    }

    private void addComputer() {
        String id = input.required("Mã máy: ");
        ComputerSection section = byId(cafe.getSections(), input.required("Mã khu: "), "Khu máy");
        int status = input.number("Trạng thái (1=AVAILABLE, 2=MAINTENANCE): ", 1, 2);
        cafe.addComputer(new Computer(id, section,
                status == 1 ? ComputerStatus.AVAILABLE : ComputerStatus.MAINTENANCE));
        System.out.println("Đã thêm máy " + id);
    }

    private void addCustomer() {
        String id = input.required("Mã khách: ");
        cafe.addCustomer(new Customer(id, input.required("Tên khách: ")));
        System.out.println("Đã thêm khách " + id);
    }

    private void addEmployee() {
        String id = input.required("Mã nhân viên: ");
        String name = input.required("Tên nhân viên: ");
        int status = input.number("Trạng thái (1=ACTIVE, 2=INACTIVE): ", 1, 2);
        cafe.addEmployee(new Employee(id, name,
                status == 1 ? EmployeeStatus.ACTIVE : EmployeeStatus.INACTIVE));
        System.out.println("Đã thêm nhân viên " + id);
    }

    private void addFood() {
        String id = input.required("Mã món: ");
        String name = input.required("Tên món: ");
        cafe.addFood(new Food(id, name, input.money("Giá món (đồng): ")));
        System.out.println("Đã thêm món " + id);
    }

    private void openSession() {
        String id = input.required("Mã phiên: ");
        Customer customer = byId(cafe.getCustomers(), input.required("Mã khách: "), "Khách");
        Computer computer = byId(cafe.getComputers(), input.required("Mã máy: "), "Máy");
        Employee employee = byId(cafe.getEmployees(), input.required("Mã nhân viên mở phiên: "), "Nhân viên");
        LocalDateTime time = input.time("Giờ mở (yyyy-MM-dd HH:mm): ");
        cafe.openSession(id, customer, computer, employee, time);
        System.out.println("Đã mở phiên " + id + " bởi " + employee.getEmployeeName());
    }

    private void endSession() {
        Session session = byId(cafe.getSessions(), input.required("Mã phiên: "), "Phiên");
        cafe.endSession(session, input.time("Giờ kết thúc (yyyy-MM-dd HH:mm): "));
        System.out.println("Đã kết thúc phiên " + session.getId());
    }

    private void orderFood() {
        String id = input.required("Mã lần gọi món: ");
        Session session = byId(cafe.getSessions(), input.required("Mã phiên: "), "Phiên");
        Employee employee = byId(cafe.getEmployees(), input.required("Mã nhân viên xử lý: "), "Nhân viên");
        LocalDateTime when = input.time("Giờ gọi món (yyyy-MM-dd HH:mm): ");
        int lines = input.number("Số dòng món (1-20): ", 1, 20);
        Food[] foods = new Food[lines];
        int[] quantities = new int[lines];
        for (int i = 0; i < lines; i++) {
            System.out.println("Dòng " + (i + 1) + ":");
            foods[i] = byId(cafe.getFoods(), input.required("  Mã món: "), "Món");
            quantities[i] = input.number("  Số lượng (1-1000000): ", 1, 1000000);
        }
        cafe.order(id, session, employee, when, foods, quantities);
        System.out.println("Đã ghi nhận gọi món " + id);
    }

    private void issueReceipt() {
        String id = input.required("Mã hóa đơn: ");
        Session session = byId(cafe.getSessions(), input.required("Mã phiên: "), "Phiên");
        Employee employee = byId(cafe.getEmployees(), input.required("Mã nhân viên lập: "), "Nhân viên");
        Receipt receipt = cafe.issueReceipt(id, session, employee);
        System.out.println("Đã lập hóa đơn " + id + ", tổng tiền " + receipt.getTotalAmount() + " đồng");
    }

    private void pay() {
        String id = input.required("Mã thanh toán: ");
        Receipt receipt = byId(cafe.getReceipts(), input.required("Mã hóa đơn: "), "Hóa đơn");
        LocalDateTime when = input.time("Giờ thanh toán (yyyy-MM-dd HH:mm): ");
        int method = input.number("Phương thức (1=CASH, 2=BANK_TRANSFER, 3=CARD): ", 1, 3);
        System.out.println("Tổng cần thanh toán: " + receipt.getTotalAmount() + " đồng");
        BigDecimal amount = input.money("Số tiền nhận: ");
        Payment payment = cafe.pay(id, receipt, when, PaymentMethod.values()[method - 1], amount);
        System.out.println("Đã thanh toán " + payment.getId());
    }

    private void search() {
        int type = input.number("Loại (1=Khu, 2=Máy, 3=Khách, 4=Nhân viên, 5=Món, 6=Phiên, 7=Gọi món, 8=Hóa đơn, 9=Thanh toán): ", 1, 9);
        String id = input.required("Mã cần tìm: ");
        switch (type) {
            case 1: System.out.println(describe(byId(cafe.getSections(), id, "Khu máy"))); break;
            case 2: System.out.println(describe(byId(cafe.getComputers(), id, "Máy"))); break;
            case 3: System.out.println(describe(byId(cafe.getCustomers(), id, "Khách"))); break;
            case 4: System.out.println(describe(byId(cafe.getEmployees(), id, "Nhân viên"))); break;
            case 5: System.out.println(describe(byId(cafe.getFoods(), id, "Món"))); break;
            case 6: System.out.println(describe(byId(cafe.getSessions(), id, "Phiên"))); break;
            case 7: System.out.println(describe(byId(cafe.getServices(), id, "Gọi món"))); break;
            case 8: System.out.println(describe(byId(cafe.getReceipts(), id, "Hóa đơn"))); break;
            case 9: System.out.println(describe(byId(cafe.getPayments(), id, "Thanh toán"))); break;
            default: throw new IllegalStateException("Unknown type");
        }
    }

    private void showAll() {
        show("Khu máy", cafe.getSections());
        show("Máy tính", cafe.getComputers());
        show("Khách", cafe.getCustomers());
        show("Nhân viên", cafe.getEmployees());
        show("Món", cafe.getFoods());
        show("Phiên", cafe.getSessions());
        show("Gọi món", cafe.getServices());
        show("Hóa đơn", cafe.getReceipts());
        show("Thanh toán", cafe.getPayments());
    }

    private void show(String label, List<? extends Identifiable> values) {
        System.out.println("\n" + label + " (" + values.size() + "):");
        for (Identifiable value : values) System.out.println("  " + describe(value));
    }

    private String describe(Identifiable item) {
        if (item instanceof ComputerSection) {
            ComputerSection x = (ComputerSection) item;
            return x.getId() + " | " + x.getSectionName() + " | " + x.getSectionPrice() + " đồng/giờ";
        }
        if (item instanceof Computer) {
            Computer x = (Computer) item;
            return x.getId() + " | khu " + x.getSection().getId() + " | " + x.getComputerStatus();
        }
        if (item instanceof Customer) {
            Customer x = (Customer) item;
            return x.getId() + " | " + x.getName();
        }
        if (item instanceof Employee) {
            Employee x = (Employee) item;
            return x.getId() + " | " + x.getEmployeeName() + " | " + x.getEmployeeStatus();
        }
        if (item instanceof Food) {
            Food x = (Food) item;
            return x.getId() + " | " + x.getFoodName() + " | " + x.getPrice() + " đồng";
        }
        if (item instanceof Session) {
            Session x = (Session) item;
            return x.getId() + " | khách " + x.getCustomer().getId() + " | máy " + x.getComputer().getId()
                    + " | mở bởi " + x.getOpenedBy().getEmployeeName() + " | " + x.getSessionStatus()
                    + " | " + x.getTimeStart() + " -> " + x.getTimeEnd();
        }
        if (item instanceof netcafe.model.FoodService) {
            netcafe.model.FoodService x = (netcafe.model.FoodService) item;
            return x.getId() + " | phiên " + x.getSession().getId() + " | nhân viên " + x.getEmployee().getId()
                    + " | " + x.getTotal() + " đồng";
        }
        if (item instanceof Receipt) {
            Receipt x = (Receipt) item;
            return x.getId() + " | phiên " + x.getSession().getId() + " | nhân viên " + x.getEmployee().getId()
                    + " | " + x.getTotalAmount() + " đồng";
        }
        if (item instanceof Payment) {
            Payment x = (Payment) item;
            return x.getId() + " | hóa đơn " + x.getReceipt().getId() + " | " + x.getPaymentMethod()
                    + " | " + x.getAmount() + " đồng";
        }
        return item.getId();
    }

    private static <T extends Identifiable> T byId(List<T> items, String id, String label) {
        for (T item : items) if (item.getId().equals(id)) return item;
        throw new EntityNotFoundException(label + " không tồn tại với mã " + id);
    }

    private static String errorMessage(RuntimeException error) {
        String detail = error.getMessage() == null ? "" : error.getMessage();
        if (error instanceof DuplicateIdException || error instanceof EntityNotFoundException
                || error instanceof ComputerUnavailableException || error instanceof ActiveSessionExistsException
                || error instanceof InactiveEmployeeException || error instanceof ReceiptAlreadyExistsException
                || error instanceof PaymentAlreadyExistsException || error instanceof PaymentAmountMismatchException
                || error instanceof InvalidTimeException || error instanceof InvalidOrderException
                || error instanceof SessionStateException || error instanceof ValidationException) return detail;
        return "Lỗi chưa xử lý (" + error.getClass().getSimpleName() + "): " + detail;
    }

}

package netcafe;
import netcafe.Service.*;
import java.util.Scanner;
public final class Main {
  public static void main(String[] args) {
    try { System.setOut(new java.io.PrintStream(System.out, true, "UTF-8")); }
    catch (java.io.UnsupportedEncodingException e) { throw new IllegalStateException(e); }
    NetCafe cafe=SampleData.create();
    if (args.length == 0 || (args.length == 1 && "--menu".equals(args[0]))) {
      new ConsoleMenu(cafe, new Scanner(System.in, "UTF-8")).run();
      return;
    }
    int from = 1, to = 30;
    if (args.length == 1 && "--all".equals(args[0])) {
      // Keep noninteractive output available for reports and Java/C# comparison.
    } else if (args.length == 2 && "--query".equals(args[0])) {
      from = to = Integer.parseInt(args[1]);
    } else if (args.length == 2 && "--group".equals(args[0])) {
      int group = Integer.parseInt(args[1]);
      if (group < 1 || group > 3) throw new IllegalArgumentException("Group must be 1..3");
      from = (group - 1) * 10 + 1; to = group * 10;
    } else {
      throw new IllegalArgumentException("Use: Main [--menu | --all | --query 1..30 | --group 1..3]");
    }
    if (from < 1 || to > 30) throw new IllegalArgumentException("Query must be 1..30");
    ReportMenu.printQueries(cafe, from, to);
  }

}

# NetCafeMIS — project IntelliJ từ src.zip

Project này đóng gói từ đúng `src.zip` bạn gửi. Toàn bộ file Java được giữ nguyên; chỉ bổ sung `pom.xml` và hướng dẫn này. Dùng JDK 21 trở lên; cấu hình build chọn Java 21. Đã kiểm tra bằng JDK 21 và Maven 3.9.9.

## Mở bằng IntelliJ

1. Giải nén ZIP vào một thư mục mới, ví dụ `OOP/NetCafeMIS-IntelliJ`.
2. Chọn **File → Open**, mở `pom.xml` trong thư mục vừa giải nén và chọn **Open as Project**. Nếu được hỏi, chọn **New Window** để không dùng nhầm cấu hình chạy của project cũ. Thư mục project phải chứa cả `pom.xml` và `src`.
3. Chờ Maven import hoàn tất. Trong **File → Project Structure → Project**, chọn SDK đã cài từ JDK 21 trở lên. Nếu cần, đồng bộ lại Maven bằng nút Reload/Sync.
4. Chọn **Build → Rebuild Project**; nếu bước này có lỗi, xem log Build trước khi chạy tiếp.
5. Mở `src/main/java/netcafe/Main.java`, nhấn nút Run cạnh hàm main để tạo cấu hình chạy mới cho project này.

Không có argument: mở menu nhập liệu. Trong **Run → Edit Configurations → Program arguments**, có thể chọn:

| Argument | Chức năng |
|---|---|
| `--menu` hoặc để trống | Menu tương tác |
| `--all` | In cả 30 truy vấn |
| `--query 5` | In truy vấn số 5 |
| `--group 2` | In nhóm truy vấn 11–20 |

Bản nguồn bạn gửi dùng `--all` để in 30 truy vấn; không dùng `--queries` của phiên bản trước.

## Chạy bằng Maven và terminal

```text
mvn clean package
java -jar target/netcafe-intellij-1.0.0.jar
java -jar target/netcafe-intellij-1.0.0.jar --all
```

Kiểm tra nghiệp vụ (Windows):

```text
java -cp "target/classes;target/test-classes" netcafe.ValidationSmokeTest
```

Trên Linux/macOS, thay `;` bằng `:`. `ValidationSmokeTest` là chương trình main độc lập, cần chạy lệnh trên để thực thi các kiểm tra.

## Về lỗi ClassNotFoundException

`Could not find or load main class netcafe.Main` có nghĩa Java không tìm được `netcafe/Main.class` trong classpath đang chạy. Có file `Main.java` trong editor chưa có nghĩa file đã được biên dịch và cấu hình chạy đã trỏ đúng module.

ZIP gốc chỉ chứa `src`, không kèm cấu hình build hoặc cấu hình IntelliJ của máy bạn. Bản đóng gói này thêm mô tả project để IntelliJ tự nhận `src/main/java` là thư mục nguồn và `src/test/java` là thư mục kiểm tra. Với Maven, lớp Main sau build nằm ở `target/classes/netcafe/Main.class`.

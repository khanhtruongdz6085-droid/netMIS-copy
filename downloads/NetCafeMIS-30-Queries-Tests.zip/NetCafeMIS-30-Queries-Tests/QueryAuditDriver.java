import netcafe.Service.NetCafe;
import netcafe.ReportMenu;
import netcafe.enums.*;
import netcafe.model.*;
import netcafe.model.NetSpecs.*;
import netcafe.model.customer.Customer;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.*;
import java.util.*;

/** Loads generated event ledgers through services and exports actual DAO query results. */
public final class QueryAuditDriver {
    static String arg(String[] a,int i){return a.length>i&&!a[i].equals("~")?a[i]:null;}
    static BigDecimal money(String s){return s==null?null:new BigDecimal(s);}
    static LocalDate day(String s){return s==null?null:LocalDate.parse(s);}
    static LocalDateTime moment(String s){return s==null?null:LocalDateTime.parse(s);}
    static List<String> query(NetCafe c,int n,String p) {
        switch(n) {
            case 1:return c.getComputerDao().lietKeMayTrong();
            case 2:return c.getComputerDao().lietKeMayBaoTri();
            case 3:return c.getComputerSectionDao().demMayTheoKhuVaTrangThai();
            case 4:return c.getComputerSectionDao().timKhuGiaCao(money(p));
            case 5:return c.getSessionDao().lichSuPhienTheoMay(p);
            case 6:return c.getSessionDao().lietKePhienDangChoi();
            case 7:return c.getSessionDao().phienChoiTu120Phut();
            case 8:return c.getComputerDao().tongPhutChoiTheoMay(day(p));
            case 9:return c.getComputerDao().mayChuaTungDuocSuDung();
            case 10:return c.getSessionDao().tamTinhTienPhienDangChoi(moment(p));
            case 11:return c.getSessionDao().lichSuPhienTheoKhach(p);
            case 12:return c.getCustomerDao().xuatKhachChuaTungChoi();
            case 13:return c.getCustomerDao().demPhienHoanTatTheoKhach();
            case 14:return c.getFoodDao().timMonTheoGia(money(p));
            case 15:return c.getFoodServiceDao().chiTietGoiMonTheoPhien(p);
            case 16:return c.getSessionDao().tongTienMonTheoPhien();
            case 17:return c.getSessionDao().phienHoanTatKhongGoiMon();
            case 18:return c.getFoodDao().monDuocGoiNhieuNhat();
            case 19:return c.getFoodServiceDao().lanGoiMonVuotNguong(money(p));
            case 20:return c.getEmployeeDao().thongKeGoiMonTheoNhanVien(day(p));
            case 21:return c.getReceiptDao().hoaDonChuaThanhToan();
            case 22:return c.getPaymentDao().doanhThuTheoNgay();
            case 23:return c.getPaymentDao().thongKeThanhToanTheoPhuongThuc();
            case 24:return c.getReceiptDao().hoaDonGiaTriLonNhat();
            case 25:return c.getPaymentDao().topKhachThanhToanNhieuNhat();
            case 26:return c.getEmployeeDao().giaTriHoaDonTheoNhanVien();
            case 27:return c.getCustomerDao().tienConThuTheoKhach();
            case 28:return c.getComputerSectionDao().doanhThuTheoKhuMay();
            case 29:return c.getFoodDao().monTonKhoThap(Integer.parseInt(p));
            case 30:return c.getSessionDao().phienHoanTatChuaCoHoaDon();
            default:throw new IllegalArgumentException("Unsupported query "+n);
        }
    }
    static String state(NetCafe c) {
        StringBuilder s=new StringBuilder();
        s.append(c.getSections().size()).append('/').append(c.getCustomers().size()).append('/').append(c.getEmployees().size());
        for(Computer pc:c.getComputers())s.append(pc.getId()).append(pc.getComputerStatus());
        for(Food f:c.getFoods())s.append(f.getId()).append(':').append(f.getStockQuantity());
        for(Session x:c.getSessions())s.append(x.getId()).append(x.getSessionStatus()).append(x.getTimeEnd()).append(x.getFoodServices().size());
        s.append('/').append(c.getServices().size()).append('/').append(c.getReceipts().size()).append('/').append(c.getPayments().size()).append('/').append(c.collectedAmount());
        return s.toString();
    }
    static String b64(String s){return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8));}
    public static void main(String[] files)throws Exception {
        for(String file:files){
            NetCafe c=new NetCafe();int line=0;
            for(String text:Files.readAllLines(Paths.get(file),StandardCharsets.UTF_8)){
                line++;if(text.isEmpty()||text.startsWith("#"))continue;
                String[] a=text.split("\t",-1);
                try {
                    switch(a[0]){
                        case "SAMPLE":c=netcafe.SampleData.create();break;
                        case "SECTION":c.addSection(new ComputerSection(a[1],a[2],money(a[3])));break;
                        case "COMPUTER":c.addComputer(new Computer(a[1],c.getComputerSectionDao().findById(a[2]).orElseThrow(),ComputerStatus.valueOf(a[3])));break;
                        case "CUSTOMER":c.addCustomer(new Customer(a[1],a[2]));break;
                        case "EMPLOYEE":c.addEmployee(new Employee(a[1],a[2],EmployeeStatus.valueOf(a[3])));break;
                        case "FOOD":c.addFood(new Food(a[1],a[2],money(a[3]),Integer.parseInt(a[4])));break;
                        case "OPEN":c.openSession(a[1],c.getCustomerDao().findById(a[2]).orElseThrow(),c.getComputerDao().findById(a[3]).orElseThrow(),c.getEmployeeDao().findById(a[4]).orElseThrow(),moment(a[5]));break;
                        case "ORDER":{
                            String[] entries=a[5].split(",");Food[] foods=new Food[entries.length];int[] quantities=new int[entries.length];
                            for(int i=0;i<entries.length;i++){String[] pair=entries[i].split(":");foods[i]=c.getFoodDao().findById(pair[0]).orElseThrow();quantities[i]=Integer.parseInt(pair[1]);}
                            c.order(a[1],c.getSessionDao().findById(a[2]).orElseThrow(),c.getEmployeeDao().findById(a[3]).orElseThrow(),moment(a[4]),foods,quantities);break;
                        }
                        case "END":c.endSession(c.getSessionDao().findById(a[1]).orElseThrow(),moment(a[2]));break;
                        case "RECEIPT":c.issueReceipt(a[1],c.getSessionDao().findById(a[2]).orElseThrow(),c.getEmployeeDao().findById(a[3]).orElseThrow());break;
                        case "PAY":{
                            Receipt r=c.getReceiptDao().findById(a[2]).orElseThrow();
                            c.pay(a[1],r,moment(a[3]),PaymentMethod.valueOf(a[4]),r.getTotalAmount());break;
                        }
                        case "RESTOCK":c.restockFood(c.getFoodDao().findById(a[1]).orElseThrow(),Integer.parseInt(a[2]));break;
                        case "QUERY":{
                            int n=Integer.parseInt(a[2]);String before=state(c);
                            try{
                                List<String> rows=query(c,n,arg(a,3));
                                if(!state(c).equals(before))throw new AssertionError("Query mutated data");
                                StringJoiner encoded=new StringJoiner(",");for(String row:rows)encoded.add(b64(row));
                                System.out.println(a[1]+"\t"+n+"\tOK\t"+encoded);
                            }catch(RuntimeException e){
                                if(!state(c).equals(before))throw new AssertionError("Rejected query mutated data");
                                System.out.println(a[1]+"\t"+n+"\tERROR\t"+e.getClass().getSimpleName()+"\t"+b64(String.valueOf(e.getMessage())));
                            }
                            break;
                        }
                        default:throw new IllegalArgumentException("Unknown event "+a[0]);
                    }
                }catch(Exception e){throw new IllegalStateException(file+":"+line+": "+a[0],e);}
            }
        }
    }
}

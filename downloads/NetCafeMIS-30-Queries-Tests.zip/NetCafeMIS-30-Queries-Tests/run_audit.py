"""Independent Decimal/datetime oracle and reproducible generated ledgers for 30 DAO queries."""
from pathlib import Path
from decimal import Decimal as D, ROUND_HALF_UP
from datetime import datetime, date, time, timedelta
from collections import Counter, defaultdict
import base64, json, random, subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/java-intellij-ready/NetCafeMIS/src')
JAVA_BIN = Path('/workspace/netmis-tools/jdk-21.0.12.1+1/bin')
STATUSES = ['AVAILABLE', 'IN_USE', 'MAINTENANCE']
METHODS = ['CASH', 'BANK_TRANSFER', 'CARD']
ZERO = D(0)

def cash(value):
    value = D(value)
    return '0' if not value else format(value.normalize(), 'f')

def jt(value):
    if value is None: return 'null'
    return value.isoformat(timespec='seconds' if value.second else 'minutes')

def row(*parts): return ' | '.join(str(p) for p in parts)

class Model:
    def __init__(self):
        self.sections={}; self.computers={}; self.customers={}; self.employees={}
        self.foods={}; self.sessions={}; self.orders={}; self.receipts={}; self.payments={}
    def apply(self, a):
        op,*v=a
        if op=='SECTION': self.sections[v[0]]={'name':v[1],'price':D(v[2])}
        elif op=='COMPUTER': self.computers[v[0]]={'section':v[1],'status':v[2]}
        elif op=='CUSTOMER': self.customers[v[0]]=v[1]
        elif op=='EMPLOYEE': self.employees[v[0]]={'name':v[1],'status':v[2]}
        elif op=='FOOD': self.foods[v[0]]={'name':v[1],'price':D(v[2]),'stock':int(v[3])}
        elif op=='OPEN':
            sid,cid,pc,employee,start=v
            self.sessions[sid]={'id':sid,'customer':cid,'pc':pc,'employee':employee,'start':datetime.fromisoformat(start),'end':None}
            self.computers[pc]['status']='IN_USE'
        elif op=='END':
            s=self.sessions[v[0]]; s['end']=datetime.fromisoformat(v[1]); self.computers[s['pc']]['status']='AVAILABLE'
        elif op=='ORDER':
            oid,sid,employee,when,entries=v; quantities={}
            for entry in entries.split(','):
                fid,amount=entry.split(':'); quantities[fid]=quantities.get(fid,0)+int(amount)
            total=ZERO
            for fid,amount in quantities.items():
                self.foods[fid]['stock']-=amount; total+=self.foods[fid]['price']*amount
            self.orders[oid]={'id':oid,'session':sid,'employee':employee,'time':datetime.fromisoformat(when),'lines':quantities,'total':total}
        elif op=='RESTOCK': self.foods[v[0]]['stock']+=int(v[1])
        elif op=='RECEIPT':
            rid,sid,employee=v; s=self.sessions[sid]
            computer=self.charge(s,s['end']); services=sum((o['total'] for o in self.orders.values() if o['session']==sid),ZERO)
            self.receipts[rid]={'id':rid,'session':sid,'employee':employee,'computer':computer,'services':services,'total':computer+services}
        elif op=='PAY':
            pid,rid,when,method=v
            self.payments[pid]={'receipt':rid,'time':datetime.fromisoformat(when),'method':method,'amount':self.receipts[rid]['total']}
        else: raise ValueError(op)
    def charge(self,s,at):
        # Whole-second ledgers: directly compute elapsed hours at the section's hourly rate.
        rate=self.sections[self.computers[s['pc']]['section']]['price']
        seconds=D(str((at-s['start']).total_seconds()))
        return (rate*seconds/D(3600)).quantize(D(1),rounding=ROUND_HALF_UP)
    def is_paid(self,rid): return any(p['receipt']==rid for p in self.payments.values())
    def query(self,q,p=None):
        ss=list(self.sessions.values()); oo=list(self.orders.values()); rr=list(self.receipts.values()); pp=list(self.payments.values())
        completed=[s for s in ss if s['end'] is not None]; active=[s for s in ss if s['end'] is None]
        if q in (4,14,19):
            if p is None or D(p)<0:return ('ERROR','ValidationException')
            p=D(p)
        if q in (8,20):
            if p is None:return ('ERROR','ValidationException')
            p=date.fromisoformat(p)
        if q==10:
            if p is None:return ('ERROR','ValidationException')
            p=datetime.fromisoformat(p)
        if q==29:
            p=int(p)
            if p<0:return ('ERROR','ValidationException')
        if q in (5,11,15):
            if p is None or not p.strip():return ('ERROR','ValidationException')
            p=p.strip(); table={5:self.computers,11:self.customers,15:self.sessions}[q]
            if p not in table:return ('ERROR','EntityNotFoundException')
        result=[]
        if q==1:
            ids=[i for i,c in self.computers.items() if c['status']=='AVAILABLE']
            ids.sort(key=lambda i:(self.sections[self.computers[i]['section']]['price'],i))
            for i in ids:
                section=self.sections[self.computers[i]['section']];result.append(row(i,section['name'],cash(section['price'])))
        elif q==2:
            result=[row(i,self.sections[self.computers[i]['section']]['name']) for i in sorted(self.computers) if self.computers[i]['status']=='MAINTENANCE']
        elif q==3:
            for section in sorted(self.sections):
                for status in STATUSES:
                    count=sum(c['section']==section and c['status']==status for c in self.computers.values())
                    result.append(row(section,status,count))
        elif q==4:
            ids=[i for i,s in self.sections.items() if s['price']>p];ids.sort(key=lambda i:-self.sections[i]['price'])
            result=[row(i,self.sections[i]['name'],cash(self.sections[i]['price'])) for i in ids]
        elif q==5:
            entries=sorted((s for s in ss if s['pc']==p),key=lambda s:s['start'],reverse=True)
            for s in entries:result.append(row(s['id'],self.customers[s['customer']],jt(s['start']),jt(s['end']),'ACTIVE' if s['end'] is None else 'COMPLETED',self.employees[s['employee']]['name']))
        elif q==6:
            for s in sorted(active,key=lambda s:s['id']):
                section=self.sections[self.computers[s['pc']]['section']]
                result.append(row(s['id'],self.customers[s['customer']],s['pc'],section['name'],jt(s['start']),self.employees[s['employee']]['name']))
        elif q==7:
            duration={s['id']:int((s['end']-s['start']).total_seconds())//60 for s in completed}
            result=[row(s['id'],str(duration[s['id']])+' phút') for s in sorted(completed,key=lambda s:-duration[s['id']]) if duration[s['id']]>=120]
        elif q==8:
            # Independent daily oracle: distribute whole-second sessions into day buckets before querying.
            buckets=defaultdict(int)
            for s in completed:
                cursor=s['start']
                while cursor<s['end']:
                    midnight=datetime.combine(cursor.date()+timedelta(days=1),time())
                    stop=min(midnight,s['end'])
                    buckets[(s['pc'],cursor.date())]+=int((stop-cursor).total_seconds());cursor=stop
            result=[row(pc,str(buckets[(pc,p)]//60)+' phút') for pc in sorted(self.computers)]
        elif q==9:
            used={s['pc'] for s in ss};result=[pc for pc in sorted(self.computers) if pc not in used]
        elif q==10:
            for s in sorted(active,key=lambda s:s['id']):
                if s['start']<=p:result.append(row(s['id'],cash(self.charge(s,p))))
        elif q==11:
            result=[row(s['id'],s['pc'],'ACTIVE' if s['end'] is None else 'COMPLETED',jt(s['start'])) for s in sorted(ss,key=lambda s:s['start'],reverse=True) if s['customer']==p]
        elif q==12:
            used={s['customer'] for s in ss};result=[row(cid,name) for cid,name in self.customers.items() if cid not in used]
        elif q==13:
            counts=Counter(s['customer'] for s in completed)
            result=[row(cid,counts[cid]) for cid in sorted(self.customers,key=lambda cid:(-counts[cid],cid))]
        elif q==14:
            ids=sorted(self.foods,key=lambda fid:(self.foods[fid]['price'],fid))
            result=[row(fid,self.foods[fid]['name'],cash(self.foods[fid]['price'])) for fid in ids if self.foods[fid]['price']<=p]
        elif q==15:
            for order in oo:
                if order['session']==p:
                    for fid,amount in order['lines'].items():result.append(row(order['id'],self.employees[order['employee']]['name'],self.foods[fid]['name'],amount,cash(self.foods[fid]['price']),cash(self.foods[fid]['price']*amount)))
        elif q==16:
            totals=defaultdict(lambda:ZERO)
            for order in oo:totals[order['session']]+=order['total']
            result=[row(sid,cash(totals[sid])) for sid in sorted(self.sessions,key=lambda sid:(-totals[sid],sid))]
        elif q==17:
            used={o['session'] for o in oo};result=[s['id'] for s in completed if s['id'] not in used]
        elif q==18:
            counts=Counter()
            for order in oo:counts.update(order['lines'])
            best=max(counts.values(),default=0);result=[row(fid,counts[fid]) for fid in sorted(counts) if counts[fid]==best]
        elif q==19:
            for order in sorted(oo,key=lambda o:o['id']):
                if order['total']>p:result.append(row(order['id'],self.customers[self.sessions[order['session']]['customer']],cash(order['total'])))
        elif q==20:
            totals=defaultdict(lambda:ZERO);counts=Counter()
            for order in oo:
                if order['time'].date()==p:totals[order['employee']]+=order['total'];counts[order['employee']]+=1
            result=[row(e,counts[e],cash(totals[e])) for e in sorted(self.employees)]
        elif q==21:
            for receipt in sorted(rr,key=lambda r:r['id']):
                if not self.is_paid(receipt['id']):result.append(row(receipt['id'],self.customers[self.sessions[receipt['session']]['customer']],self.employees[receipt['employee']]['name'],cash(receipt['total'])))
        elif q==22:
            totals=defaultdict(lambda:ZERO)
            for payment in pp:totals[payment['time'].date()]+=payment['amount']
            result=[row(d,cash(totals[d])) for d in sorted(totals)]
        elif q==23:
            for method in METHODS:
                payments=[p for p in pp if p['method']==method]
                result.append(row(method,len(payments),cash(sum((p['amount'] for p in payments),ZERO))))
        elif q==24:
            maximum=max((r['total'] for r in rr),default=ZERO)
            for r in rr:
                if r['total']==maximum:result.append(row(r['id'],self.customers[self.sessions[r['session']]['customer']],r['session'],cash(r['total'])))
        elif q==25:
            totals=defaultdict(lambda:ZERO)
            for payment in pp:
                cid=self.sessions[self.receipts[payment['receipt']]['session']]['customer'];totals[cid]+=payment['amount']
            for cid in sorted(totals,key=lambda cid:(-totals[cid],cid))[:3]:result.append(row(cid,self.customers[cid],cash(totals[cid])))
        elif q==26:
            for e in sorted(self.employees):
                receipts=[r for r in rr if r['employee']==e]
                total=sum((r['total'] for r in receipts),ZERO)
                received=sum((p['amount'] for p in pp if self.receipts[p['receipt']]['employee']==e),ZERO)
                result.append(row(e,len(receipts),cash(total),cash(received),cash(total-received)))
        elif q==27:
            balances=defaultdict(lambda:ZERO)
            for r in rr:
                if not self.is_paid(r['id']):balances[self.sessions[r['session']]['customer']]+=r['total']
            result=[row(cid,cash(balances[cid])) for cid in sorted(self.customers) if balances[cid]>0]
        elif q==28:
            computer=defaultdict(lambda:ZERO);services=defaultdict(lambda:ZERO);actual=defaultdict(lambda:ZERO)
            for payment in pp:
                r=self.receipts[payment['receipt']];section=self.computers[self.sessions[r['session']]['pc']]['section']
                actual[section]+=payment['amount'];computer[section]+=r['computer'];services[section]+=r['services']
            result=[row(section,cash(computer[section]),cash(services[section]),cash(actual[section])) for section in sorted(self.sections)]
        elif q==29:
            ids=sorted(self.foods,key=lambda fid:(self.foods[fid]['stock'],fid))
            result=[row(fid,self.foods[fid]['name'],'còn '+str(self.foods[fid]['stock'])) for fid in ids if self.foods[fid]['stock']<=p]
        elif q==30:
            billed={r['session'] for r in rr};result=[row(s['id'],self.customers[s['customer']]) for s in completed if s['id'] not in billed]
        else:raise ValueError(q)
        return ('OK',result)

class Dataset:
    def __init__(self,name):self.name=name;self.events=[];self.model=Model();self.expected=[]
    def event(self,*args):
        a=[str(v) for v in args];self.events.append('\t'.join(a));self.model.apply(a)
    def query(self,q,p=None,label='base'):
        case=f'{self.name}/{label}/Q{q:02d}/{len(self.expected)}'
        expected=self.model.query(q,p)
        self.expected.append({'case':case,'query':q,'parameter':p,'expected_status':expected[0],'expected':expected[1]})
        self.events.append('\t'.join(['QUERY',case,str(q),p if p is not None else '~']))
    def suite(self,label='base'):
        m=self.model
        params={4:'12000',5:next(iter(m.computers),'MISSING'),8:'2026-10-06',10:'2026-10-06T12:00',11:next(iter(m.customers),'MISSING'),14:'15000',15:next(iter(m.sessions),'MISSING'),19:'15000',20:'2026-10-05',29:'5'}
        for q in range(1,31):self.query(q,params.get(q),label)
    def variants(self):
        for q in (4,14,19):
            for v in ('0','0.1','12000','12000.50','13000','15000','1000000000000000000000000000000','-1',None):self.query(q,v,'money-boundary')
        for q in (8,20):
            for v in ('2026-10-05','2026-10-06','2028-02-28','2028-02-29','2028-03-01','2030-01-01',None):self.query(q,v,'date-boundary')
        for v in ('2026-10-01T00:00','2026-10-05T00:00','2028-02-29T12:00','2030-01-01T00:00',None):self.query(10,v,'as-of')
        for q,table in ((5,self.model.computers),(11,self.model.customers),(15,self.model.sessions)):
            for identifier in list(table)[:4]:
                self.query(q,identifier,'id-existing');self.query(q,' '+identifier+' ','id-trim')
            for v in ('MISSING',' ',None):self.query(q,v,'id-invalid')
        for v in ('-1','0','1','5','10','2147483647'):self.query(29,v,'stock-boundary')
    def save(self):
        path=ROOT/'datasets'/(self.name+'.tsv');path.parent.mkdir(exist_ok=True)
        path.write_text('\n'.join(self.events)+'\n',encoding='utf-8');return path

def catalog(d):
    for identifier,name,price in [('K0','Miễn phí','0'),('K2','VIP','12000.50'),('K1','Thường','12000'),('K3','Khu chưa có máy','12000')]:d.event('SECTION',identifier,name,price)
    for pc,section,status in [('PC02','K2','AVAILABLE'),('PC01','K1','AVAILABLE'),('PC03','K1','MAINTENANCE'),('PC04','K0','AVAILABLE'),('PC05','K1','AVAILABLE'),('PC06','K2','AVAILABLE')]:d.event('COMPUTER',pc,section,status)
    for i in range(1,9):d.event('CUSTOMER',f'C{i:02}', 'Nguyễn Văn An' if i<3 else f'Khách {i}')
    for eid,name,status in [('E02','Thu ngân 2','ACTIVE'),('E01','Thu ngân 1','ACTIVE'),('E03','Chưa lập đơn','INACTIVE')]:d.event('EMPLOYEE',eid,name,status)
    for fid,name,price,stock in [('F02','Nước','15000',100000),('F01','Mì','13000',100000),('F03','Miễn phí','0',0),('F04','Giá lẻ','0.10',100000),('F05','Đồng giá','15000',5)]:d.event('FOOD',fid,name,price,stock)

def complete(d,sid,cid,pc,start,seconds,orders=(),receipt=True,pay=False,method='CASH',employee='E01',payment_delay=0):
    d.event('OPEN',sid,cid,pc,employee,start.isoformat())
    for j,(offset,items,handler) in enumerate(orders):d.event('ORDER',f'O-{sid}-{j}',sid,handler,(start+timedelta(seconds=offset)).isoformat(),items)
    end=start+timedelta(seconds=seconds);d.event('END',sid,end.isoformat())
    if receipt:
        d.event('RECEIPT','R-'+sid,sid,'E02' if employee=='E01' else 'E01')
        if pay:d.event('PAY','P-'+sid,'R-'+sid,(end+timedelta(seconds=payment_delay)).isoformat(),method)
    return end

def build_datasets():
    datasets=[]
    d=Dataset('original-sample')
    for section,name,price in [('CS01','Khu thường','12000'),('CS02','Khu VIP','20000')]:d.event('SECTION',section,name,price)
    for i,section,status in [(1,'CS01','AVAILABLE'),(2,'CS01','AVAILABLE'),(3,'CS02','AVAILABLE'),(4,'CS02','AVAILABLE'),(5,'CS01','MAINTENANCE'),(6,'CS02','AVAILABLE')]:d.event('COMPUTER',f'PC{i:02}',section,status)
    for i,name in enumerate(['Lamine Yamal','Bruno Fernandes','Cristiano Ronaldo','Lionel Messi','Khách chưa chơi'],1):d.event('CUSTOMER',f'C{i:02}',name)
    for eid,name,status in [('E01','Erik TenHag','ACTIVE'),('E02','Anchelotti','ACTIVE'),('E03','Luis Enrique','INACTIVE')]:d.event('EMPLOYEE',eid,name,status)
    for fid,name,price,stock in [('F01','Mì ly',13000,10),('F02','Nước ngọt',15000,12),('F03','Snack',7000,8)]:d.event('FOOD',fid,name,price,stock)
    d.event('OPEN','S01','C01','PC01','E01','2026-10-05T08:00');d.event('ORDER','SV01','S01','E01','2026-10-05T08:20','F01:1,F02:1')
    d.event('OPEN','S02','C02','PC03','E02','2026-10-05T09:00');d.event('ORDER','SV02','S02','E02','2026-10-05T09:30','F01:2')
    d.event('OPEN','S03','C03','PC04','E01','2026-10-05T10:00')
    for sid,end in [('S01','10:00'),('S02','10:30'),('S03','11:00')]:d.event('END',sid,'2026-10-05T'+end)
    d.event('OPEN','S04','C01','PC02','E02','2026-10-05T11:00');d.event('ORDER','SV03','S04','E01','2026-10-05T11:15','F02:2')
    d.event('RECEIPT','R01','S01','E02');d.event('RECEIPT','R02','S02','E01');d.event('PAY','P01','R01','2026-10-05T10:05','CASH')
    d.event('OPEN','S05','C04','PC01','E01','2026-10-06T09:00');d.event('ORDER','SV04','S05','E01','2026-10-06T09:30','F03:3')
    d.event('END','S05','2026-10-06T12:00');d.event('RECEIPT','R03','S05','E02');d.event('PAY','P02','R03','2026-10-06T12:05','BANK_TRANSFER')
    d.event('OPEN','S06','C02','PC03','E02','2026-10-06T12:00');d.event('END','S06','2026-10-06T13:00');d.event('RECEIPT','R04','S06','E01');d.event('PAY','P03','R04','2026-10-06T13:05','CARD')
    # Load the ACTUAL SampleData.create() in Java; the Python ledger remains independent.
    d.events=['SAMPLE'];d.suite();d.variants();datasets.append(d)
    d=Dataset('empty');d.suite();d.variants();datasets.append(d)
    d=Dataset('catalog-only');catalog(d);d.suite();d.variants();datasets.append(d)
    d=Dataset('boundaries');catalog(d)
    base=datetime(2026,10,5,8)
    complete(d,'S01','C01','PC01',base,7199,[(0,'F01:1,F04:1','E01'),(300,'F02:1','E02')],True,True,payment_delay=86400)
    complete(d,'S02','C02','PC02',base,7200,[],True,False)
    complete(d,'S03','C03','PC04',base,7201,[],True,True,method='CARD')
    complete(d,'S04','C01','PC01',datetime(2026,10,5,23,30),3600,[(1800,'F02:2,F02:1','E02')],False)
    complete(d,'S05','C04','PC02',datetime(2026,10,6,10),60,[(0,'F04:3','E01')],True,True,'BANK_TRANSFER',payment_delay=172800)
    complete(d,'S06','C05','PC04',datetime(2026,10,6,10),60,[],False)
    d.event('OPEN','S07','C06','PC01','E01','2026-10-06T12:00:00')
    d.event('ORDER','O-active','S07','E02','2026-10-06T12:00:00','F01:2,F02:3')
    d.event('OPEN','S08','C07','PC02','E02','2026-10-06T14:00:00')
    d.suite();d.variants();d.query(10,'2026-10-06T12:00','exact-active-start');d.query(10,'2026-10-06T13:00','skip-later-active');datasets.append(d)
    d=Dataset('ties');catalog(d)
    for i,cid in enumerate(['C04','C03','C02','C01']):
        complete(d,f'T{i}',cid,'PC01',datetime(2026,10,5,8+i),3600,[(0,'F01:1,F02:1','E01')],True,True,METHODS[i%3])
    d.suite();d.variants();datasets.append(d)
    d=Dataset('zero-invoices');catalog(d)
    d.event('RESTOCK','F03',3)
    for i in range(3):complete(d,f'Z{i}',f'C0{i+1}','PC04',datetime(2026,10,5,8+i),60,[(0,'F03:1','E01')],True,i<2,METHODS[i])
    d.suite();d.variants();datasets.append(d)
    for seed in range(24):
        rng=random.Random(20261017+seed);d=Dataset(f'random-{seed:02}');catalog(d)
        clock=datetime(2028,2,28,21,30)
        for i in range(80):
            duration=rng.choice([1,59,60,119,7199,7200,7201,86401,rng.randint(1,18000)])
            cid=f'C{rng.randint(1,6):02}';pc=rng.choice(['PC01','PC02','PC04','PC05'])
            orders=[]
            for j in range(rng.randrange(4)):
                fid=rng.choice(['F01','F02','F04']);amount=rng.randint(1,5)
                entries=f'{fid}:{amount}'+(f',{fid}:1' if j%2 else '')
                orders.append((rng.randrange(duration+1),entries,rng.choice(['E01','E02'])))
            has_receipt=rng.random()<0.8;paid=has_receipt and rng.random()<0.65
            end=complete(d,f'G{i:03}',cid,pc,clock,duration,orders,has_receipt,paid,rng.choice(METHODS),rng.choice(['E01','E02']),rng.randrange(172800))
            clock=end+timedelta(seconds=rng.randrange(300))
            if i in (0,19,39):d.suite(f'snapshot-{i}')
        d.event('OPEN','A1','C07','PC01','E01',clock.isoformat());d.event('ORDER','OA','A1','E02',clock.isoformat(),'F02:2')
        d.event('OPEN','A2','C08','PC02','E02',(clock+timedelta(hours=2)).isoformat())
        d.suite();d.variants()
        for offset in (0,1,2,23):d.query(10,(clock+timedelta(hours=offset)).isoformat(),f'generated-asof-{offset}')
        for offset in (-1,0,1):d.query(8,(clock.date()+timedelta(days=offset)).isoformat(),'generated-report-day')
        datasets.append(d)
    d=Dataset('aggregate-int-limit');catalog(d)
    d.event('OPEN','S01','C01','PC01','E01','2026-10-05T08:00:00')
    d.event('RESTOCK','F01',2147483647-100000)
    d.event('ORDER','BIG','S01','E01','2026-10-05T08:00:00','F01:2147483647')
    d.suite('at-int-limit')
    d.event('RESTOCK','F01',1);d.event('ORDER','ONE','S01','E01','2026-10-05T08:01:00','F01:1')
    d.event('ORDER','OTHER','S01','E01','2026-10-05T08:01:00','F02:1')
    d.suite('over-int-limit');d.variants();datasets.append(d)
    return datasets

def main():
    datasets=build_datasets();files=[d.save() for d in datasets]
    expected=[case for d in datasets for case in d.expected]
    (ROOT/'expected.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2),encoding='utf-8')
    classes=ROOT/'classes';classes.mkdir(exist_ok=True)
    cmd=[str(JAVA_BIN/'javac'),'--release','21','-encoding','UTF-8','-d',str(classes),*[str(p) for p in sorted(SOURCE.rglob('*.java'))],str(ROOT/'QueryAuditDriver.java')]
    result=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8')
    if result.returncode:raise RuntimeError(result.stderr)
    result=subprocess.run([str(JAVA_BIN/'java'),'-cp',str(classes),'QueryAuditDriver',*[str(p) for p in files]],capture_output=True,text=True,encoding='utf-8',timeout=60)
    (ROOT/'actual.tsv').write_text(result.stdout,encoding='utf-8')
    if result.returncode:raise RuntimeError(result.stderr)
    actual={}
    for line in result.stdout.splitlines():
        a=line.split('\t');case,q,status=a[:3]
        value=[base64.b64decode(s).decode('utf-8') for s in a[3].split(',') if s] if status=='OK' else a[3]
        actual[case]={'status':status,'value':value}
    if len(actual)!=len(expected):raise AssertionError(f'Missing/duplicate test output: {len(actual)} / {len(expected)}')
    results=[];summary={q:Counter() for q in range(1,31)}
    for e in expected:
        a=actual[e['case']];passed=a['status']==e['expected_status'] and a['value']==e['expected']
        record=dict(e,actual_status=a['status'],actual=a['value'],passed=passed);results.append(record)
        summary[e['query']]['pass' if passed else 'fail']+=1
        if e['expected_status']=='ERROR':summary[e['query']]['expected_rejections']+=1
    (ROOT/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    failures=[r for r in results if not r['passed']]
    lines=['query\tpassed\tfailed\texpected_rejections']+[f'Q{q:02}\t{summary[q]["pass"]}\t{summary[q]["fail"]}\t{summary[q]["expected_rejections"]}' for q in range(1,31)]
    (ROOT/'summary.tsv').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('DATASETS',len(datasets),'QUERY_CHECKS',len(results),'PASSED',sum(r['passed'] for r in results),'FAILED',len(failures))
    print('\n'.join(lines))
    for f in failures[:12]:print(json.dumps(f,ensure_ascii=False))
    print('GENERATED_SESSIONS',sum(len(d.model.sessions) for d in datasets),'ORDERS',sum(len(d.model.orders) for d in datasets),'RECEIPTS',sum(len(d.model.receipts) for d in datasets),'PAYMENTS',sum(len(d.model.payments) for d in datasets))
    # Check the actual Main --all -> ReportMenu switch, not just DAO calls.
    p=subprocess.run([str(JAVA_BIN/'java'),'-cp',str(classes),'netcafe.Main','--all'],capture_output=True,text=True,encoding='utf-8',check=True,timeout=30)
    (ROOT/'main-all.txt').write_text(p.stdout,encoding='utf-8')
    printed={};number=None
    import re
    for line in p.stdout.splitlines():
        match=re.match(r'^Q(\d{2}) \| .* \| (\d+) row\(s\)$',line)
        if match:number=int(match[1]);printed[number]=[]
        elif number and line and line!='(Không có kết quả)':printed[number].append(line)
    if set(printed)!=set(range(1,31)):raise AssertionError('Main --all did not print all 30 queries')
    # ReportMenu uses exactly these fixed sample parameters.
    parameters={4:'12000',5:'PC01',8:'2026-10-06',10:'2026-10-05T12:00',11:'C01',14:'15000',15:'S01',19:'15000',20:'2026-10-05',29:'5'}
    for q in range(1,31):
        status,values=datasets[0].model.query(q,parameters.get(q))
        if status!='OK' or values!=printed[q]:raise AssertionError(f'Main --all wrong rows for Q{q:02}: {printed[q]} != {values}')
    print('MAIN_ALL 30/30 output comparisons PASS')
    (ROOT/'run-metadata.json').write_text(json.dumps({'datasets':len(datasets),'query_checks':len(results),'passed':sum(r['passed'] for r in results),'failed':len(failures),'main_all_pass':30,'query_failures':[r['case'] for r in failures],'expected_rejections':sum(r['expected_status']=='ERROR' for r in results),'sessions':sum(len(d.model.sessions) for d in datasets),'orders':sum(len(d.model.orders) for d in datasets),'receipts':sum(len(d.model.receipts) for d in datasets),'payments':sum(len(d.model.payments) for d in datasets)},indent=2),encoding='utf-8')
    raise SystemExit(1 if failures else 0)

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project',type=Path,help='Project folder containing src/main/java')
    parser.add_argument('--java-home',type=Path,help='JDK 21+ folder containing bin/java and bin/javac')
    options=parser.parse_args()
    if options.project:SOURCE=options.project.resolve()/'src'
    if options.java_home:JAVA_BIN=options.java_home.resolve()/'bin'
    if not (SOURCE/'main/java/netcafe/Main.java').is_file():
        parser.error('Use --project to select the latest uploaded NetCafeMIS project')
    main()
